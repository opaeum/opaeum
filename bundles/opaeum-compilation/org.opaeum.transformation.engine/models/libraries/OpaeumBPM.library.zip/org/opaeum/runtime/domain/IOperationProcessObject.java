package org.opaeum.runtime.domain;

import org.opaeum.runtime.domain.IProcessObject;


public interface IOperationProcessObject extends IProcessObject{
}
