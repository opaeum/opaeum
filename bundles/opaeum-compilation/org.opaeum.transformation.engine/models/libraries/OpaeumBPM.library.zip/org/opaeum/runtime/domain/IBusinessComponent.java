package org.opaeum.runtime.domain;

import org.opaeum.runtime.domain.IPersistentObject;


public interface IBusinessComponent extends IPersistentObject{
}
