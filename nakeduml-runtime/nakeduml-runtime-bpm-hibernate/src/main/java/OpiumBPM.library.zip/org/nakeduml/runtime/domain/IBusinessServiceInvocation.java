package org.nakeduml.runtime.domain;

public interface IBusinessServiceInvocation extends IPersistentObject{
	boolean started();
	boolean completed();
}
