package org.nakeduml.runtime.domain;

public interface IOperationProcessObject extends IProcessObject{
}
