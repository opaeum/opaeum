package org.nakeduml.runtime.domain;

public interface IProcessInvocation extends IBusinessServiceInvocation{
	IProcessObject getProcessObject();
}
