package org.nakeduml.runtime.domain;

public interface IBusinessComponent extends IPersistentObject{
}
