/*****************************************************************************
 * Copyright (c) 2002 - 2004, Holongate.org.                                 *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.draw2d.ui;

import java.util.HashMap;

import org.eclipse.draw2d.J2DGraphics;
import org.eclipse.jface.preference.BooleanFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;
import org.holongate.j2d.J2DRegistry;

/**
 * A preference page for the Draw2d hints.
 * User can choose to use the Java2D engine or not, and, if Java2D is
 * used, specify if the line width scales or not.
 *
 * @author Chtistophe Avare
 * @version $Revision: 1.2 $
 */
public class Draw2dPreferencePage
	extends FieldEditorPreferencePage
	implements IWorkbenchPreferencePage {

	private static final HashMap hints = new HashMap(2);

	public static final String P_USE_JAVA2D = "prefs.draw2d.useJava2d";

	public static final String P_FIXED_LINE_WIDTH =
		"prefs.draw2d.fixedLineWidth";

	private BooleanFieldEditor usej2d;
	private BooleanFieldEditor fixedLineWidth;

	public Draw2dPreferencePage() {
		super(GRID);
		setPreferenceStore(Draw2dPlugin.getDefault().getPreferenceStore());
		setDescription(
			Draw2dPlugin.getResourceString("prefs.draw2d.description"));
	}

	public void init(IWorkbench workbench) {
	}

	public void createFieldEditors() {
		addField(
			usej2d =
				new BooleanFieldEditor(
					P_USE_JAVA2D,
					Draw2dPlugin.getResourceString(P_USE_JAVA2D),
					getFieldEditorParent()));
		addField(
			fixedLineWidth =
				new BooleanFieldEditor(
					P_FIXED_LINE_WIDTH,
					Draw2dPlugin.getResourceString(P_FIXED_LINE_WIDTH),
					getFieldEditorParent()));
	}

	public boolean performOk() {
		boolean f = super.performOk();
		if (f) {
			updateHints(getPreferenceStore());
		}
		return f;
	}

	public static void updateHints(IPreferenceStore store) {
		boolean b = store.getBoolean(P_FIXED_LINE_WIDTH);
		hints.put(J2DGraphics.KEY_FIXED_LINEWIDTH, Boolean.valueOf(b));
		b = store.getBoolean(P_USE_JAVA2D);
		hints.put(J2DGraphics.KEY_USE_JAVA2D, Boolean.valueOf(b));
		J2DRegistry.setHints(hints);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.util.IPropertyChangeListener#propertyChange(org.eclipse.jface.util.PropertyChangeEvent)
	 */
	public void propertyChange(PropertyChangeEvent event) {
		if (event.getSource() == usej2d) {
			fixedLineWidth.setEnabled(
				usej2d.getBooleanValue(),
				getFieldEditorParent());
		}
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.preference.FieldEditorPreferencePage#initialize()
	 */
	protected void initialize() {
		super.initialize();
		fixedLineWidth.setEnabled(
			usej2d.getBooleanValue(),
			getFieldEditorParent());
	}
}
