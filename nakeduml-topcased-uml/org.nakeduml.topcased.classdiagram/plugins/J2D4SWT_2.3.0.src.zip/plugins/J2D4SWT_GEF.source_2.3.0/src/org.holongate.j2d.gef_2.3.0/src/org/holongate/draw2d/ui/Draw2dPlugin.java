/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.draw2d.ui;

import java.util.ResourceBundle;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPluginDescriptor;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.ui.IStartup;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

/**
 * A simple that manage resource bundles and preferences for the Java2D support inside
 * Draw2d.
 * <p>
 * It provides the following services:
 * <ul>
 * <li>Persistence of the Dava2d preferences</li>
 * </ul>
 * This plugin is ready to be internationalized through its descriptor resource bundle
 * (i.e. international strings are taken from the plugin_*.properties files).
 * </p>
 * 
 * @author Christophe Avare
 * @version $Revision: 1.2.4.4 $
 */
public class Draw2dPlugin extends AbstractUIPlugin implements IStartup {
	//The shared instance.
	private static Draw2dPlugin plugin;
	//Resource bundle.
	private ResourceBundle resourceBundle;

	public Draw2dPlugin(IPluginDescriptor descriptor) {
		super(descriptor);
	}

	public Draw2dPlugin() {
		super();
	}

	/**
	 * The plugin startup code initializes the preferences to suitable default values.
	 * 
	 * @throws CoreException
	 *             When there is no extension for the runtime platform.
	 */
	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;
		resourceBundle = Platform.getResourceBundle(getBundle());
		// Set the rendering hints with the current values fom the preference
		// store
		Draw2dPreferencePage.updateHints(getPreferenceStore());
	}

	/**
	 * Returns the shared instance.
	 * 
	 * @return Draw2dPlugin The worskpace plugin instance
	 */
	public static Draw2dPlugin getDefault() {
		return plugin;
	}

	/**
	 * Returns a string from the resource bundle, knowing its key. Note: the generated
	 * code is not strong enough because a NullPointerException is raised if there is no
	 * resource bundle, instead of 'key' to be returned for consistency.
	 * 
	 * @return The string from the plugin's resource bundle, or 'key' if not found.
	 */
	public static String getResourceString(String key) {
		ResourceBundle bundle = Draw2dPlugin.getDefault().getResourceBundle();
		try {
			return bundle.getString(key);
			//		} catch (MissingResourceException e) {
		} catch (Exception e) {
			return key;
		}
	}

	/**
	 * Returns the plugin's resource bundle. Note that for this plugin, the resource
	 * bundle is the same as the plugin descriptor resource bundle.
	 * 
	 * @return The plugin's resource bundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * Sets the default values of the preferences:
	 * <ul>
	 * <li>Use Java2d for Draw2d rendering = true</li>
	 * <li>Fixed line width = true</li>
	 * </ul>
	 * 
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#initializeDefaultPreferences(org.eclipse.jface.preference.IPreferenceStore)
	 */
	protected void initializeDefaultPreferences(IPreferenceStore store) {
		store.setDefault(Draw2dPreferencePage.P_USE_JAVA2D, true);
		store.setDefault(Draw2dPreferencePage.P_FIXED_LINE_WIDTH, false);
	}

	/**
	 * Reads the current preferences for GEF hints before any GEF related code starts up.
	 * do nothing, except ensure that the startup() code is run.
	 * 
	 * @see org.eclipse.ui.IStartup#earlyStartup()
	 */
	public void earlyStartup() {
	}
}