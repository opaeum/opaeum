/*****************************************************************************
 * Copyright (c) 2002 - 2004, Holongate.org.                                 *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.eclipse.draw2d;

import org.eclipse.draw2d.Graphics;
import org.eclipse.draw2d.GraphicsSource;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.widgets.Control;
import org.holongate.j2d.Graphics2DFactory;
import org.holongate.j2d.J2DRegistry;

/**
 * A J2DGraphicsSource creates J2DGraphics objects that renders onto a target control. A
 * Graphics2DFactory the size of the control is internally created and disposed with the
 * control. The factory tracks the control's size so that drawings can appear on the whole
 * surface. By using an internal Graphics2DFactory we do not constraint the clients to use
 * a J2DCanvas as their primary canvas: any SWT control is suitable for rendering.
 * 
 * @author Christophe Avare
 * @version $Revision: 1.2.4.2 $
 */
public class J2DGraphicsSource implements GraphicsSource {
	private Control control;
	private J2DGraphics g2d;
	private Graphics2DFactory factory;
	private BufferedGraphicsSource gs;

	/**
	 * A J2DGraphicsSource is built for a Control. The control is usually the one set in
	 * the LightweightSystem.
	 * 
	 * @param ctrl
	 *            The Control that will ultimately receive the drawings
	 */
	public J2DGraphicsSource(Control ctrl) {
		control = ctrl;
		if (J2DRegistry.getHints().get(J2DGraphics.KEY_USE_JAVA2D) == Boolean.TRUE) {
			factory = J2DRegistry.createGraphics2DFactory(control);
			control.addControlListener(new ControlAdapter() {
				public void controlResized(ControlEvent e) {
					// FIX by Daniel Mazurek
					// Check if control has pixel to draw on!
					if (control.getSize().x > 0 && control.getSize().y > 0) {
						factory.setSize(control.getSize());
					}
				}
			});
		} else {
			gs = new BufferedGraphicsSource(ctrl);
		}
	}

	protected void updateRegion(Rectangle region) {
		GC gc = new GC(control);
		org.eclipse.swt.graphics.Rectangle r = new org.eclipse.swt.graphics.Rectangle(
			region.x, region.y, region.width, region.height);
		factory.update(r, gc);
		gc.dispose();
	}

	/**
	 * Flushing the graphics means moving the requested offscreen image region to the
	 * control drawing surface.
	 * 
	 * @see org.eclipse.draw2d.GraphicsSource#flushGraphics(org.eclipse.draw2d.geometry.Rectangle)
	 */
	public void flushGraphics(Rectangle region) {
		//System.err.println("flushGraphics("+region+")");
		if (gs == null) {
			updateRegion(region);
			g2d.dispose();
			J2DGraphics.flushImageCache();
		} else {
			gs.flushGraphics(region);
		}
	}

	/**
	 * Creates a new J2DGraphics bound to the target control using the internal
	 * Graphics2DFactory.
	 * 
	 * @see org.eclipse.draw2d.GraphicsSource#getGraphics(org.eclipse.draw2d.geometry.Rectangle)
	 */
	public Graphics getGraphics(Rectangle region) {
		//System.err.println("getGraphics("+region+")");
		if (gs == null) {
			if (factory.getOffscreenImage() != null) {
				g2d = new J2DGraphics(control, factory);
				g2d.setClip(region);
			} else {
				g2d = null;
			}
			return g2d;
		}
		return gs.getGraphics(region);
	}
}