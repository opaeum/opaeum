/*****************************************************************************
 * Copyright (c) 2002 - 2004, Holongate.org.                                  *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.eclipse.draw2d;

import org.eclipse.swt.widgets.Canvas;

/**
 * A J2DLightweightSystem is just a convenient class to force the gaphics source
 * of the update manager to be an instance of J2DGraphicsSource.
 * The folowing alternatives will have the same effect:
 * <pre>
 * Lightweightsystem lws = new LightweightSystem(myCanvas);
 * lws.getUpdateManager().setGrapgicsSource(new J2DGraphicsSource(myCanvas));
 * </pre>
 * and:
* <pre>
 * Lightweightsystem lws = new J2DLightweightSystem(myCanvas);
 * </pre>
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1 $
 */
public class J2DLightweightSystem extends LightweightSystem {
	public J2DLightweightSystem() {
		super();
	}
	/**
	 * @param c
	 */
	public J2DLightweightSystem(Canvas c) {
		super(c);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.draw2d.LightweightSystem#setControl(org.eclipse.swt.widgets.Canvas)
	 */
	public void setControl(Canvas c) {
		super.setControl(c);
		// Override the graphics source
		getUpdateManager().setGraphicsSource(new J2DGraphicsSource(c));
	}
}