/*****************************************************************************
 * Copyright (c) 2002 - 2004, Holongate.org.                                 *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.eclipse.draw2d;

/**
 * A J2DScalableLayeredPane behaves like a ScalableLayeredPane except that no intermediate
 * ScaledGraphics is created: the scale factor is directly applied to the Graphics object
 * because java2D will compute and apply the correct transformation for subsequent calls.
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1.2.1.2.1 $
 */
public class J2DScalableLayeredPane extends ScalableLayeredPane {

	public J2DScalableLayeredPane() {
		super();
	}

	/**
	 * No ScaledGraphics needed here, only setScale() on the passed graphics. Graphics
	 * state is preserved.
	 * 
	 * @see org.eclipse.draw2d.Figure#paintClientArea(org.eclipse.draw2d.Graphics)
	 */
	protected void paintClientArea(Graphics graphics) {
		if (getChildren().isEmpty())
			return;
		if (!(graphics instanceof J2DGraphics)) {
			super.paintClientArea(graphics);
		} else {
			double scale = getScale();
			if (scale == 1.0) {
				// Hopefully this will have the same effet
				// on the inherited code!
				super.paintClientArea(graphics);
			} else {
				boolean optimizeClip = getBorder() == null || getBorder().isOpaque();
				if (!optimizeClip)
					graphics.clipRect(getBounds().getCropped(getInsets()));
				graphics.pushState();
				graphics.scale(scale);
				paintChildren(graphics);
				graphics.popState();
			}
		}
	}
}