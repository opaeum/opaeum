/*****************************************************************************
 * Copyright (c) 2002 - 2004, Holongate.org.                                 *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.eclipse.gef.editparts;

import org.eclipse.draw2d.J2DScalableFreeformLayeredPane;
import org.eclipse.draw2d.ScalableFreeformLayeredPane;

/**
 * A J2DScalableFreeformRootEditPart is a ScalableFreeformRootEditPart
 * that creates a scalable layer of J2DScalableFreeformLayeredPane instead of
 * ScalableFreeformLayeredPane.
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1.4.1 $
 */
public class J2DScalableFreeformRootEditPart
	extends ScalableFreeformRootEditPart {
	public J2DScalableFreeformRootEditPart() {
		super();
	}
	/* (non-Javadoc)
	 * @see org.eclipse.gef.editparts.ScalableFreeformRootEditPart#createScaledLayers()
	 */
	protected ScalableFreeformLayeredPane createScaledLayers() {
		J2DScalableFreeformLayeredPane layers =
			new J2DScalableFreeformLayeredPane();
		layers.add(createGridLayer(), GRID_LAYER);
		layers.add(getPrintableLayers(), PRINTABLE_LAYERS);
		layers.add(new FeedbackLayer(), SCALED_FEEDBACK_LAYER);
		return layers;
	}

}
