/*****************************************************************************
 * Copyright (c) 2002 - 2004, Holongate.org.                                 *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.eclipse.gef.editparts;

import org.eclipse.draw2d.J2DScalableLayeredPane;
import org.eclipse.draw2d.ScalableLayeredPane;

/**
 * A J2DScalableRootEditPart is a ScalableRootEditPart that creates a scalable layer of
 * J2DScalableLayeredPane instead of ScalableLayeredPane.
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1.2.1 $
 */
public class J2DScalableRootEditPart extends ScalableRootEditPart {
	public J2DScalableRootEditPart() {
		super();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.gef.editparts.ScalableFreeformRootEditPart#createScaledLayers()
	 */
	protected ScalableLayeredPane createScaledLayers() {
		ScalableLayeredPane layers = new J2DScalableLayeredPane();
		layers.add(createGridLayer(), GRID_LAYER);
		layers.add(getPrintableLayers(), PRINTABLE_LAYERS);
		return layers;
	}
}