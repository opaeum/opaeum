/*****************************************************************************
 * Copyright (c) 2002 - 2004, Holongate.org.                                 *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.eclipse.gef.ui.parts;

import org.eclipse.gef.GraphicalViewer;
import org.eclipse.swt.widgets.Composite;

/**
 * A J2DGraphicalEditor is a GraphicalEditor whose internal viewer is
 * a J2DScrollingGraphicalViewer instead of ScrollingGraphicalViewer.
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1.4.1 $
 */
public abstract class J2DGraphicalEditor extends GraphicalEditor {

	public J2DGraphicalEditor() {
		super();
	}

	/**
	 * Creates the GraphicalViewer on the specified <code>Composite</code>.
	 * A J2DScrollingGraphicalViewer is internally created.
	 *
	 * @param parent The parent composite
	 */
	protected void createGraphicalViewer(Composite parent) {
		GraphicalViewer viewer = new J2DScrollingGraphicalViewer();
		viewer.createControl(parent);
		setGraphicalViewer(viewer);
		configureGraphicalViewer();
		hookGraphicalViewer();
		initializeGraphicalViewer();
	}
}
