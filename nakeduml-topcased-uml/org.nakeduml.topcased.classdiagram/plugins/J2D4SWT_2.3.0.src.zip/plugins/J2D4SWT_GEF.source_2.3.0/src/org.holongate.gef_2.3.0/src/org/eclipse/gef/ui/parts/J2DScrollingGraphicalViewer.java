/*****************************************************************************
 * Copyright (c) 2002 - 2004, Holongate.org.                                 *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.eclipse.gef.ui.parts;

import org.eclipse.draw2d.J2DLightweightSystem;
import org.eclipse.draw2d.LightweightSystem;

/**
 * A J2DScrollingGraphicalViewer is a ScrollingGraphicalViewer but
 * a J2DLightweightSystem is created instead of a LightweightSystem.
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1 $
 */
public class J2DScrollingGraphicalViewer extends ScrollingGraphicalViewer {

	/**
	 * Constructs a ScrollingGraphicalViewer;
	 */
	public J2DScrollingGraphicalViewer() {
		super();
	}

	/**
	 * Internally creates a J2DLightweightSystem.
	 *
	 * @see org.eclipse.gef.ui.parts.GraphicalViewerImpl#createLightweightSystem()
	 */
	protected LightweightSystem createLightweightSystem() {
		return new J2DLightweightSystem();
	}
}