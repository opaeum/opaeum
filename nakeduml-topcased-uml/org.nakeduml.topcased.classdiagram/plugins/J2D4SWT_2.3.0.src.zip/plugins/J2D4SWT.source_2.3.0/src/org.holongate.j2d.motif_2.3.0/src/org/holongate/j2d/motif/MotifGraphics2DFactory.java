/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d.motif;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Control;
import org.holongate.j2d.Graphics2DFactory;

/**
 * This is the Motif wrapper for the Java2D for SWT plugin. The wrapper uses
 * native acceleration through the XImage structure.
 * For a better efficiency, only one XImage is created by factory, and destroyed
 * when the factory itself is disposed.
 * The XImage structure is created on the fly inside the JNI code so that the
 * byte ordering and mask bits are set by the X server and not computed by hand.
 * This class uses the undocumented SWT OS class to call OS.XDestroyImage(), and
 * may be not portable across different SWT releases.
 *
 * @author Christophe Avare
 * @version $Revision: 1.5 $
 */
public class MotifGraphics2DFactory extends Graphics2DFactory {
	private int xim = 0;
	static {
		Graphics2DFactory.loadLibrary("motif", "2.0.0");
	}

	/**
	 * Constructor for MotifGraphics2DFactory.
	 * @param control
	 */
	public MotifGraphics2DFactory(Control control) {
		super(control);
	}

	/**
	 * Constructor for MotifGraphics2DFactory.
	 */
	public MotifGraphics2DFactory() {
		super();
	}

	/**
	 * Do a bulk bitblt between a byte array and the SWT drawing surface
	 *
	 * Coordinates are all expressed in the SWT widget coordinates, as the information
	 * usually comes from a paint event on such a surface.
	 * It is up to the native code to understand this coordinate system.
	 * <B>The byte array must have a known pixel layout, fixed for all the images:
	 * this is the main weakness of the current code!</B>
	 * 
	 * @param drawable A native handle to the target widget, usually the handle attribute: must be of type GtkWidget!
	 * @param gc A native handle to the gc, usually the handle attribute: must be of type GdkGC!
	 * @param xDest The x coordinate of the upper-left destination area, in widget coordinates
	 * @param yDest The y coordinate of the upper-left destination area, in widget coordinates
	 * @param width The width of the destination area
	 * @param height The height of the destination area
	 * @param data The byte array associated with the image pixels
	 * @param xim The XImage pointer
	 * 
	 * @return A pointer (passed as an int) to the XImage that can be used next time
	 */
	static private native int putImage(
		int drawable,
		int gc,
		int xDest,
		int yDest,
		int width,
		int height,
		int[] data,
		int xim);

	static private native void XDestroyImage(int xim);

	public BufferedImage createBufferedImage(int width, int height) {
		return new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
	}

	public Graphics2D createGraphics(BufferedImage image) {
		return image.createGraphics();
	}

	/**
	 * @see org.holongate.j2d.Graphics2DFactory#update(org.eclipse.swt.graphics.Rectangle, org.eclipse.swt.graphics.GC)
	 */
	public void update(Rectangle damaged, GC gc) {
		if ((damaged.width == 0) || (damaged.height == 0)) {
			return;
		}

		boolean full = trimUpdateRegion(damaged);
		BufferedImage image = getOffscreenImage();
		int data[] = null;
		if (full) {
			data =
				((DataBufferInt) image.getRaster().getDataBuffer()).getData();
		} else {
			java.awt.Rectangle subimage =
				new java.awt.Rectangle(
					damaged.x,
					damaged.y,
					damaged.width,
					damaged.height);
			data =
				((DataBufferInt) image.getData(subimage).getDataBuffer())
					.getData();
		}
		// Just pass the byte array to the native call
		xim =
			putImage(
				getControl().handle,
				gc.handle,
				damaged.x,
				damaged.y,
				damaged.width,
				damaged.height,
				data,
				xim);
		// Help the GC do its job
		data = null;
	}

	/**
	 * @see org.holongate.j2d.Graphics2DFactory#createFactory(org.eclipse.swt.widgets.Control)
	 */
	public Graphics2DFactory createFactory(Control control) {
		return new MotifGraphics2DFactory(control);
	}

	/* (non-Javadoc)
	 * @see org.holongate.j2d.Graphics2DFactory#dispose()
	 */
	public void dispose() {
		if (xim != 0) {
			XDestroyImage(xim);
		}
		xim = 0;
		super.dispose();
	}
}