#include "org_holongate_j2d_motif_MotifGraphics2DFactory.h"
#include <X11/Intrinsic.h>

/*
 * Class:     org_holongate_j2d_motif_MotifGraphics2DFactory
 * Method:    putImage
 * Signature: (IIIIII[II)I
 */
JNIEXPORT jint JNICALL Java_org_holongate_j2d_motif_MotifGraphics2DFactory_putImage
  (JNIEnv *env, jclass that, jint widget, jint gc, jint xDest, jint yDest, jint width, jint height, jintArray data, jint image) {
	char *old_data;
	unsigned int old_width,old_height;

	XImage *xim = (XImage *)image;

	jint* pixels = (*env)->GetPrimitiveArrayCritical(env, data, 0);

	Widget xwidget = (Widget) widget;
	GC xgc = (GC)gc;
	Display *display = XtDisplay(xwidget);

	// Test if we can reuse the old image
	if (xim) {
		// width has changed, the storage information should be
		// re-computed
		if ((xim->width != width)) {
			XDestroyImage(xim);
			xim = NULL;
		}
	}
	// Create a new fake image from the X server
	if (!xim) {
		// Create an XImage structure by copying a single pixel line
		// from the target widget.
		// Because we use just a single line, the network overhead is kept
		// to a minimum while letting the server compute the correct storage
		// and byte information.
		xim = XGetImage(display,XtWindow(xwidget),0,0,width,1,0xFFFFFFFF,ZPixmap);
	}
	
	// Keep the old information
	old_data = xim->data;
	old_width = xim->width;
	old_height = xim->height;

	// Replace by the current ones
	xim->data = (char *)pixels;
	xim->width = width;
	xim->height = height;

	// Display the image
	XSetClipMask(display,xgc,None);
	XPutImage(display,XtWindow(xwidget),xgc,xim,0,0,xDest,yDest,width,height);

	// Restore old values
	xim->data = old_data;
	xim->width = old_width;
	xim->height = old_height;

	// Array is released without writing back data (JNI_ABORT)
	(*env)->ReleasePrimitiveArrayCritical(env, data, pixels, JNI_ABORT);
	
	return (jint)xim;
}

/*
 * Class:     org_holongate_j2d_motif_MotifGraphics2DFactory
 * Method:    XDestroyImage
 * Signature: (I)V
 */
JNIEXPORT void JNICALL Java_org_holongate_j2d_motif_MotifGraphics2DFactory_XDestroyImage
  (JNIEnv *env, jclass that, jint xim) {

  XDestroyImage((XImage *)xim);
}
