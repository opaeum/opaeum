/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Control;

/**
 * A FastPaintableManager provides some performance enhancement by optimizing
 * the painting work when a translation is applied (other operations behave
 * like the default manager).
 * <p>
 * The optimisation uses the native widget scrolling capabilities to move the
 * unchanged part of the image on screen, and generates PAINT_ALL requests for
 * the newly displayed areas which are typically smaller than the image size.
 * </p>
 * This technique is not perfect as the offscreen image is only partially
 * repainted too. Then, if you mask/show a part of the canvas with another
 * window, you will see the untranslated (old)image.
 * </p>
 * <p>
 * Having this limitation in mind (and given that many Eclipse applications
 * have no overlapping windows), one can benefits of the best
 * memory/performance tradeoff.
 * </p>
 * <p>
 * <b>Implementation note:</b> This performance trick only works if the
 * paintable canvas is based on an SWT Canvas because other SWT widgets don't
 * have this kind of method. While this is the case for all the Holongate.org
 * implementations, the canvas type is checked inside the translate() method:
 * if the paintable canvas is not an SWT Canvas, the default (non optimized)
 * behavior is applied.
 * </p>
 * TODO: Canvas.scroll() can be simulated for all the SWT widgets using the GC
 * but requires by hand computation of the newly exposed areas
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1.2.1 $
 */
public class FastPaintableManager extends DefaultPaintableManager {
	/**
	 * Default constructor.
	 */
	public FastPaintableManager() {
		super();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#translate(int, int)
	 */
	public void translate(int dx, int dy) {
		Control control = canvas.getControl();
		// If the paintable canvas is bound to an SWT Canvas
		// We can efficiently use the scroll() method
		if (control instanceof Canvas) {
			boolean m = immediateMode;
			immediateMode = false;
			super.translate(dx, dy);
			immediateMode = m;
			if (immediateMode) {
				updateTransform();
				Point d = control.getSize();
				// Force the generated paint event to use PAINT_ALL
				canvas.setDefaultPaintMode(IPaintableCanvas.PAINT_ALL);
				// Scroll the content
				 ((Canvas) control).scroll(dx, dy, 0, 0, d.x, d.y, true);
				// Wait until all the paint events have been processed
				control.update();
				// Restore the original default paint mode
				canvas.setDefaultPaintMode(IPaintableCanvas.PAINT_DAMAGED);
			}
		} else {
			// The paintable canvas is not bound to an SWT Canvas,
			// Use the non optimized translation :(
			super.translate(dx, dy);
		}
	}
}
