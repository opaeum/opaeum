/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.eclipse.swt.graphics.Point;

/**
 * This interface is used to manage some display operations like translation, zoom and
 * rotation.
 * <p>
 * Those functions are provided by an interface and not directly through the
 * AffineTransform of the Graphics2D because we can intercept the intent (translate,
 * rotate, scale) in a more optimised way.
 * </p>
 * <p>
 * One example of such optimization is that the underlying buffered image can be resized
 * when scaling is changed and thus can quickly respond to an origin change by simply
 * scrolling the widget contents. Other alternative implementations may expose other
 * interesting behaviors like property change events.
 * </p>
 * <p>
 * This interface centralizes a very specific behavior that would otherwise be spead in
 * the control (paint, resize) events and in the rendering pipeline (transform).
 * Implementation classes are responsible to call the required paint/redraw methods
 * because the implied interface contract is that the call of any setXXX() method must
 * have an immediate effect.
 * </p>
 * <p>
 * To help in situations where many transformations are applied, but only the resulting
 * transform effect must be visible, each IPaintableManager is required to honor the
 * immediate mode flag.
 * </p>
 * <p>
 * Because paintable managers must cache some state information between calls, and the
 * expected result must be applied to a well defined IPaintableCanvas, there is no way to
 * share a paintable manager.
 * </p>
 * <p>
 * A specific protocol attach()/detach() is provided to change a given paintable manager /
 * paintable canvas association at runtime. This mechanism is used for example by the
 * performance preference page.
 * </p>
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1.2.1 $
 */
public interface IPaintableManager {
	public final static AffineTransform IDENTITY = new AffineTransform();

	/**
	 * Attach a paintable canvas to this manager.
	 * <p>
	 * This method must be called at least once for the canvas to respond to paint, resize
	 * and transform change events. A <tt>detach()</tt> must implicitely be performed if
	 * necessary.
	 * </p>
	 * <p>
	 * This method is the place of choice where all the control event listeners are bound
	 * to the control if necessary.
	 * </p>
	 * 
	 * @param canvas
	 *            The paintable canvas that will be under control of this manager
	 */
	void attach(IPaintableCanvas canvas);

	/**
	 * Detach this manager from the current paintable canvas.
	 * <p>
	 * This method is the place of choice where all the control event listeners are
	 * removed from the control if necessary.
	 * </p>
	 */
	void detach();

	/**
	 * Sets the paintable manager rendering mode to 'immediate' or 'delayed'.
	 * <p>
	 * Because a client may change many transformation parameters before the actual
	 * rendering is needed, there must be a way to defer the actual effects of those
	 * changes.
	 * </p>
	 * <p>
	 * When the parameter is <tt>true</tt>, any transformation change is immediatly
	 * applied (and thus visible to the user), when 'false' any change is postponed until
	 * the client issue a setImmediateMode(true) call. As a convenience, the
	 * applyTransform() method always resets the immediate mode to <tt>true</tt>.
	 * </p>
	 * <p>
	 * Typical code using this feature:
	 * 
	 * <pre>
	 * manager.setImmediateMode(false);
	 * manager.reset();
	 * manager.translate(100,100);
	 * manager.setScale(0.5);
	 * manager.applyTransform();
	 * </pre>
	 * 
	 * </p>
	 * 
	 * @param mode
	 *            The new manager immediate mode: if true, any transformation change will
	 *            be immediately applied.
	 */
	void setImmediateMode(boolean mode);

	/**
	 * This method (re)computes the affine transform and makes the necessary work to apply
	 * this transform to the paintable canvas.
	 * <p>
	 * The immediate mode is expected to be <tt>true</tt> after this call.
	 * </p>
	 */
	void applyTransform();

	/**
	 * Gets the managed IPaintableCanvas.
	 * <p>
	 * There is no setIPaintableCanvas method because this is an immutable property
	 * initialised by implementing classes at construction time.
	 * </p>
	 * 
	 * @return The currently managed IPaintableCanvas
	 */
	IPaintableCanvas getPaintableCanvas();

	/**
	 * Change the origin so that the upper-left corner of the drawing aera is now at pixel
	 * (x,y).
	 * <p>
	 * The (x,y) point is expressed in user (screen) coordinates (the canvas' reference
	 * frame) and any current scale or rotation is applied.
	 * </p>
	 * 
	 * @param x
	 *            The new x origin
	 * @param y
	 *            The new y origin
	 */
	void setOrigin(int x, int y);

	/**
	 * Returns the current origin, expressed in the user space.
	 * 
	 * @return A copy of current origin
	 */
	Point2D getOrigin();

	/**
	 * Translates the origin by the given delta-x and delta-y increments.
	 * <p>
	 * This increment is expressed in pixel coordinates, so that the current
	 * transformation is first inversed before the translation is applied.
	 * </p>
	 * 
	 * @param dx
	 *            The increment in the x direction
	 * @param dy
	 *            The increment in the y direction
	 */
	void translate(int dx, int dy);

	/**
	 * Uniformly changes the scale factor.
	 * <p>
	 * The same factor is applied in the x and y directions.
	 * </p>
	 * 
	 * @param s
	 *            The global scale factor
	 */
	void setScale(double s);

	/**
	 * Sets the rotation center.
	 * <p>
	 * The rotation center is expressed in user coordinates.
	 * </p>
	 * 
	 * @param x
	 *            The rotation center x coordinate
	 * @param y
	 *            The rotation center y coordinate
	 */
	void setRotationCenter(int x, int y);

	/**
	 * Returns the current rotation center, or (0,0) if none has been set.
	 * <p>
	 * One should check the rotation angle to discover if any rotation is in effect.
	 * </p>
	 * 
	 * @return The current image rotation center
	 */
	public Point2D getRotationCenter();

	/**
	 * Defines the rotation angle (in radians) around its rotation center.
	 * <p>
	 * Positive values define clockwise rotations. The current center (set by
	 * setRotationCenter) is used as the center of rotation.
	 * </p>
	 * 
	 * @param angle
	 *            The rotation angle in degrees
	 */
	void setRotationAngle(double angle);

	/**
	 * Returns the current rotation angle in radians.
	 * 
	 * @return The current rotation angle
	 */
	double getRotationAngle();

	/**
	 * Sets the transform that must be applied before any other one.
	 * <p>
	 * This transform is applied before any other transform takes place. It is useful for
	 * example to change the image orientation (portrait/landscape effect) or the scale
	 * factor depending on the screen/image resolution to compute accurate scales (i.e.
	 * measures are meaningful: 1cm on screen is x cm for a terrain map).
	 * </p>
	 * 
	 * @param t
	 *            The affine transform that will be used as the initial transform. A null
	 *            value will be changed to the IDENTITY transform.
	 */
	void setInitialTransform(AffineTransform t);

	/**
	 * Retuns a copy of the initial transform that must be applied before any other
	 * transformation.
	 * 
	 * @return an affine transform, or IDENTITY if there is no initial transform
	 */
	AffineTransform getInitialTransform();

	/**
	 * Returns the transform based on the current parameters.
	 * 
	 * @return A new affine transform computed from the manager parameters.
	 */
	AffineTransform getTransform();

	/**
	 * Returns the scale factor.
	 * 
	 * @return The current scale factor
	 */
	double getScale();

	/**
	 * Returns the transform that must be used to perform the drawings onto the target
	 * canvas.
	 * <p>
	 * This transform may be different from the one returned by getTransform() if the
	 * paintable manager uses some combinaison of control positioning and image
	 * transformations.
	 * </p>
	 * 
	 * @return A transform suitable for use on the canvas
	 */
	AffineTransform getCanvasTransform();

	/**
	 * Sets the IPaintable usable area. This information is necessary when one wants to
	 * compute the transformed image size and optimize the rendering process accordingly.
	 * <p>
	 * For example, an IPaintableManager that always center its image can compute the
	 * transformation given this information.
	 * </p>
	 * 
	 * @param size
	 *            The natural image size
	 */
	void setSize(Point size);

	/**
	 * Returns the natural image size.
	 * 
	 * @return A copy of the image size.
	 */
	Point getSize();

	/**
	 * Returns the image bounding box when the paintable manager transform is applied.
	 * <p>
	 * The transform, and not the <i>canvas transform </i>, is applied so that the
	 * resulting bounding box is the exact transformation of the whole image.
	 * </p>
	 * 
	 * @return The bounding box after the image transformation
	 */
	Rectangle2D getTransformedBounds();

	/**
	 * Reset the internal state to its defaults. Origine is (0,0), scale is (1), no
	 * rotation.
	 * <p>
	 * The initial transform is preserved.
	 * </p>
	 */
	void reset();

	/**
	 * Initializes this manager with the argument parameters.
	 * <p>
	 * The current manager must do its best effort to set all its parameters from the
	 * given manager, and initialize its internal state to suitable values.
	 * </p>
	 * <p>
	 * The manager must avoid to generate paint events because there is no guarantee that
	 * the paintable canvas is set (attach() may have not already be called).
	 * </p>
	 * 
	 * @param manager
	 */
	void init(IPaintableManager manager);

	/**
	 * Utility method to transform a point from the device space (the paintable coordinate
	 * system without transformation) to the user (SWT) coordinates.
	 * <p>
	 * Note that the Point returned is of type org.eclipse.swt.graphics.Point because it
	 * is the structure that is most useful in this coordinate system.
	 * </p>
	 * 
	 * @param p
	 *            The point in user space
	 * @return The point projected to the device (SWT) space
	 */
	public Point toUser(Point2D p);

	/**
	 * Utility method to transform a point in user space (SWT) into device coordinates.
	 * <p>
	 * This method is used for example when a mouse event must be transformed in its
	 * equivalent point in the original paintable coordinate system. If the transformation
	 * is singular, the original point is silently returned.
	 * </p>
	 * 
	 * @param x
	 *            The x coordinate
	 * @param y
	 *            The y coordinate
	 * @return The point in user coordinate
	 */
	public Point2D toDevice(int x, int y);

	/**
	 * Utility method to transform a point in device space (SWT) into user coordinates.
	 * This method is used for example when a mouse event must be transformed in its
	 * equivalent point in the original paintable coordinate system. If the transformation
	 * is singular, the original point is silently returned.
	 * 
	 * @param p
	 *            The point to be transformed
	 * @return The point in user coordinate
	 */
	public Point2D toDevice(Point p);
}
