/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.widgets.Composite;

/**
 * A TimedCanvas is a J2DCanvas whose rendering strategy has been modified to
 * compute the frame per second display rate.
 * <p>
 * This control is used within the preference page to display an animation and
 * computing the frame rate.
 * </p>
 * <p>
 * This component continuously repaint itself by calling Display.asynchExec()
 * in its applyPaintEvent() method.
 * </p>
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1 $
 */
public class TimedCanvas extends J2DCanvas implements Runnable {
	private long frames = 0;
	private long elapsedTime = 0;
	private long totalTime = 0;
	private long fps = 0;

	/**
	 * Constructor for TimedCanvas.
	 * 
	 * @param parent
	 * @param paintable
	 */
	public TimedCanvas(Composite parent, IPaintable paintable) {
		super(parent, paintable);
	}

	/**
	 * Constructor for TimedCanvas.
	 * 
	 * @param parent
	 * @param style
	 * @param paintable
	 */
	public TimedCanvas(Composite parent, int style, IPaintable paintable) {
		super(parent, style, paintable);
	}

	/**
	 * @return Returns the fps.
	 */
	public long getFps() {
		return fps;
	}

	/**
	 * The redraw strategy for this component is the same as the J2DCanvas,
	 * except that the required display interval is recorded and averaged. <br>
	 * Display.asynchExec() is called at the end of each redraw cycle to
	 * simulate continuous animation.
	 */
	public void applyPaintEvent(PaintEvent evt, int mode) {
		// Record start time
		elapsedTime = System.currentTimeMillis();
		// Do the standard painting process
		super.applyPaintEvent(evt, mode);
		// Accumulate total time and frames
		elapsedTime = System.currentTimeMillis() - elapsedTime;
		totalTime += elapsedTime;
		frames++;
		// Refresh the average fps every second
		if (totalTime >= 1000) {
			fps = 1000L * frames / totalTime;
			totalTime = frames = 0;
		}
		// Start a new cycle as soon as possible
		getDisplay().asyncExec(this);
	}

	/**
	 * When the dispatching thread dequeue the asynchExec call for this
	 * control, it immediatly starts a new paint image cycle.
	 */
	public void run() {
		if (!isDisposed()) {
			repaint();
		}
	}

}
