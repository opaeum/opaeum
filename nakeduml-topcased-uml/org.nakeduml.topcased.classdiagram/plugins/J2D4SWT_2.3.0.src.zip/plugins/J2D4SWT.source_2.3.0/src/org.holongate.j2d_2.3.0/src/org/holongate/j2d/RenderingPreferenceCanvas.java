/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

/**
 * A Composite used to display an animated canvas and a zoomable image side by
 * side on the preference page.
 * The redraw() method is redefined to force
 * the zoomed image canvas to call a paintImage() instead of redraw() because
 * we want the preferences changes to be visible. As the animated canvas
 * refreshes itself, the normal redraw() method is called.
 * 
 * @author Christophe Avare
 * @version $Revision: 1.2 $
 */
public class RenderingPreferenceCanvas extends Composite {
	private TimedCanvas animatedCanvas;
	private ZoomedImageCanvas imageCanvas;

	static private class RotatingCanvas extends TimedCanvas {
		private Label fps;
		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Runnable#run()
		 */
		public void run() {
			super.run();
			if (!isDisposed()) {
				((J2DSamplePaintable) getPaintable()).angle += 1;
				long a = getFps();
				fps.setText(
					(a == 0) ? "Computing fps..." : Long.toString(a) + " fps");
				fps.pack(true);
			}
		}

		/**
		 * @param parent
		 * @param paintable
		 */
		public RotatingCanvas(
			Composite parent,
			int style,
			IPaintable paintable) {
			super(parent, style, paintable);
			setLayout(new GridLayout());
			fps = new Label(this, SWT.NONE);
		}

	}
	public RenderingPreferenceCanvas(
		Composite parent,
		String message,
		String file) {
		super(parent, SWT.NONE);
		setLayoutData(
			new GridData(GridData.FILL_BOTH | GridData.GRAB_VERTICAL));
		GridLayout layout = new GridLayout(2, true);
		layout.horizontalSpacing = 2;
		layout.verticalSpacing = 2;
		layout.marginHeight = 0;
		layout.marginWidth = 0;
		setLayout(layout);

		animatedCanvas =
			new RotatingCanvas(
				this,
				SWT.BORDER,
				new J2DSamplePaintable(message));
		GridData gd1 = new GridData(GridData.FILL_BOTH);
		animatedCanvas.setLayoutData(gd1);

		imageCanvas = new ZoomedImageCanvas(this, SWT.BORDER, file);
		GridData gd2 = new GridData(GridData.FILL_BOTH);
		imageCanvas.setLayoutData(gd2);
	}

	/**
	 * Refresh the canvases: call paintImage() on the zoomed image and redraw()
	 * on the animated canvas.
	 */
	public void redraw() {
		imageCanvas.repaint();
		animatedCanvas.redraw();
	}
}