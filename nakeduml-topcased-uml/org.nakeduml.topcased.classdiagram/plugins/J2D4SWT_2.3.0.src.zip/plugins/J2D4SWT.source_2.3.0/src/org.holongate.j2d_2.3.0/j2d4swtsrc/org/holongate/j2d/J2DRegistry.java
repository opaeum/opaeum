/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Control;

/**
 * This facade component is used to isolate the clients like J2DCanvas from the
 * actual factory selection mechanism.
 * <p>
 * This registry may be setup from different sources:
 * <ul>
 * <li>From the J2DPlugin extension framework when the library is used inside
 * Eclipse</li>
 * <li>From a local property file when the library is used in a standalone
 * application</li>
 * <li>By a direct call from an application at the developer discretion</li>
 * </ul>
 * Debug information can be displayed when the system property -Dj2d.debug is
 * set.
 * </p>
 * <p>
 * One can also force the Graphics2DFactory to use with the -Dj2d.factory=(your
 * class). This class name must be the fully qualified name of a class
 * extending the Graphics2DFactory class (and must be in the CLASSPATH).
 * </p>
 * <p>
 * Default rendering hints turn antialiasing on: you must explicitely call
 * setHints() in your program if you want your J2DCanvas
 * objects use your own ones.
 * When the registry is used by the J2DPlugin, hints are
 * automatically set and synchronized with the workbench preferences.
 * </p>
 * 
 * @author Christophe Avare
 * @version $Revision: 1.6.2.1 $
 */
public final class J2DRegistry {
	public static final boolean DEBUG = System.getProperties().containsKey("j2d.debug"); //$NON-NLS-1$
	private static final Map hints = new HashMap();
	private static final String BUNDLE_NAME = "org.holongate.j2d.J2DRegistry"; //$NON-NLS-1$
	private static final ResourceBundle RESOURCE_BUNDLE =
		ResourceBundle.getBundle(BUNDLE_NAME);
	private static Graphics2DFactory theFactory = null;

	static {
		// Activate AA by default
		hints.put(
			RenderingHints.KEY_ANTIALIASING,
			RenderingHints.VALUE_ANTIALIAS_ON);
		hints.put(
			RenderingHints.KEY_INTERPOLATION,
			RenderingHints.VALUE_INTERPOLATION_BILINEAR);
	}

	/**
	 * Register the Graphics2DFactory that will be used.<br>
	 * 
	 * @param factory
	 *            an object inheriting from Graphics2DFactory
	 */
	public static void registerFactory(Graphics2DFactory factory) {
		theFactory = factory;
	}

	public static void printMessage(String msg, String reason) {
		if (!DEBUG) {
			return;
		}
		System.err.println("[J2D] " + msg); //$NON-NLS-1$
		if (reason != null) {
			System.err.println("[J2D] --> " + reason); //$NON-NLS-1$
		}
	}

	/**
	 * Finds and register a factory given the following rules.
	 * If j2d.factory is set, use it as the factory class,
	 * Else read the J2DRegistry.properties file and look for
	 * an entry given by the SWT.getPlatform() call.
	 * If anything fails, fallback to the SWTGraphics2DFactory class.
	 *
	 */
	private static void initFactory() {
		String key = SWT.getPlatform();
		String factory = null;
		factory = System.getProperty("j2d.factory"); //$NON-NLS-1$
		if (factory != null) {
			printMessage("Using system property...", factory); //$NON-NLS-1$
		} else {
			factory = RESOURCE_BUNDLE.getString(key);
			printMessage("Using property file...", factory); //$NON-NLS-1$
		}
		try {
			theFactory =
				(Graphics2DFactory) Class.forName(factory).newInstance();
			printMessage("Java2D for SWT will use the factory", //$NON-NLS-1$
			RESOURCE_BUNDLE.getString(key));
			return;
		} catch (Throwable e) {
			printMessage("No factory for " + key, e.toString()); //$NON-NLS-1$
		}
		if (theFactory == null) {
			theFactory = new SWTGraphics2DFactory();
			printMessage("Java2D for SWT will use the default factory", null); //$NON-NLS-1$
		}
	}

	/**
	 * The main registry entry point that returns a graphics2D factory for a
	 * given control. The internal 'model' factory is initialized if necessary
	 * and a new factory is created from the model.
	 * 
	 * @param ctrl
	 *            The SWT Control to use as the target
	 * @return A new graphics2D factory bound to the control
	 */
	public static Graphics2DFactory createGraphics2DFactory(Control ctrl) {
		if (theFactory == null) {
			initFactory();
		}
		return theFactory.createFactory(ctrl);
	}

	/**
	 * Adds / Replace the current hints with the new ones.
	 * Duplicated keys are overwritten.
	 *
	 * @param newHints The new set of hints
	 */
	static public void setHints(Map newHints) {
		hints.putAll(newHints);
	}

	/**
	 * Returns the current hint collection.
	 */
	static public Map getHints() {
		return hints;
	}

	/**
	 * An utility method that initializes a given Graphics2D object with the
	 * hints recorded through the setHints() method. This method is each time a
	 * J2DCanvas creates a new Graphics2D object.
	 * 
	 * @param g2d
	 *            The Graphics2D object to be initialized.
	 */
	static public void initGraphics(Graphics2D g2d) {
		g2d.setRenderingHints(hints);
	}

	/**
	 * Creates a new IPaintableManager given the performance level.
	 * <p>
	 * If the performance level cannot be honored, the
	 * DefaultPerformanceManager is returned.
	 * </p>
	 * 
	 * @param index
	 *            The performance level (performance increases with value,
	 *            starting at 0)
	 * @return An IPaintableManager that best match the required level
	 */
	static public IPaintableManager createPaintableManager(int index) {
		switch (index) {
			case 1 :
				return new FastPaintableManager();
			case 2 :
				return new OptimizedPaintableManager();
			default :
				return new DefaultPaintableManager();
		}
	}
}
