/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Scale;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

/**
 * The performance preference page allows the user to select a default
 * "performance level".
 * <p>
 * The performance improvement is achieved through different IPaintableManager
 * implementations. This page presents the user some hints about what benefits
 * or drawbacks he can get with a given performance level.
 * </p>
 * Information displayed in the page it taken from the plugin.properties
 * resource bundle, where all concerned properties start with <tt>prefs.performance</tt>.
 * </p>
 * <p>
 * The actual use of this preference is up to the implementor choice: there is
 * no mechanism to enforce a given performance level to be honored, its just a
 * user hint. A typical use of this hint is in conjunction with the
 * J2DRegistry:
 * 
 * <pre>
 * IPaintableCanvas canvas;
 * canvas.setPaintableManager(
 *   J2DRegistry.createPaintableManager(
 *     J2DPlugin.getDefault().getPreferenceStore().getInt(
 *       PerformancePreferencePage.P_PERFORMANCE
 *     )
 *   )
 * );
 * </pre>
 * 
 * Or, as a convenience:
 * 
 * <pre>
 * canvas.setPaintableManager(PerformancePreferencePage.createPaintableCanvas());
 * </pre>
 * 
 * </p>
 * 
 * @see org.holongate.j2d.J2DRegistry
 * @see org.holongate.j2d.IPaintableManager
 * @author Christophe Avare
 * @version $Revision: 1.2 $
 */
public class PerformancePreferencePage
	extends PreferencePage
	implements IWorkbenchPreferencePage {

	/**
	 * The performance preference key (as an int)
	 */
	public static final String P_PERFORMANCE = "prefs.performance";
	private int thrustIndex;
	private Label message;
	private Scale thrust;

	public PerformancePreferencePage() {
		super();
		setPreferenceStore(J2DPlugin.getDefault().getPreferenceStore());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.preference.PreferencePage#createContents(org.eclipse.swt.widgets.Composite)
	 */
	protected Control createContents(Composite parent) {
		Composite controls = new Composite(parent, SWT.NONE);
		controls.setLayout(new GridLayout(3, true));

		// Paintful creation and layout of the 3 scale labels...
		Label l = new Label(controls, SWT.NONE);
		l.setText(J2DPlugin.getResourceString("prefs.performance.intro"));
		GridData a = new GridData(GridData.FILL_HORIZONTAL);
		a.horizontalSpan = 3;
		l.setLayoutData(a);
		l = new Label(controls, SWT.NONE);
		l.setText(J2DPlugin.getResourceString("prefs.performance.label.0"));
		l.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_BEGINNING));
		l = new Label(controls, SWT.NONE);
		l.setText(J2DPlugin.getResourceString("prefs.performance.label.1"));
		l.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_CENTER));
		l = new Label(controls, SWT.NONE);
		l.setText(J2DPlugin.getResourceString("prefs.performance.label.2"));
		l.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_END));

		// Setup of the performance scale
		thrust = new Scale(controls, SWT.HORIZONTAL);
		GridData b = new GridData(GridData.FILL_HORIZONTAL);
		b.horizontalSpan = 3;
		thrust.setLayoutData(b);
		thrust.setMaximum(2);
		thrust.setPageIncrement(1);
		thrust.setIncrement(1);
		thrust.addSelectionListener(new SelectionAdapter() {
			/*
			 * (non-Javadoc)
			 * 
			 * @see org.eclipse.swt.events.SelectionAdapter#widgetSelected(org.eclipse.swt.events.SelectionEvent)
			 */
			public void widgetSelected(SelectionEvent e) {
				thrustIndex = thrust.getSelection();
				updateUI();
			}
		});

		// Setup the message area
		message = new Label(controls, SWT.WRAP);
		GridData c = new GridData(GridData.FILL_BOTH);
		c.horizontalSpan = 3;
		c.widthHint = 350;
		message.setLayoutData(c);

		// Initialize the widgets
		thrustIndex = getPreferenceStore().getInt(P_PERFORMANCE);
		updateUI();

		return controls;
	}

	private void updateUI() {
		thrust.setSelection(thrustIndex);
		message.setText(
			J2DPlugin.getResourceString(
				"prefs.performance.text." + thrustIndex));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.IWorkbenchPreferencePage#init(org.eclipse.ui.IWorkbench)
	 */
	public void init(IWorkbench workbench) {}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.preference.PreferencePage#performDefaults()
	 */
	protected void performDefaults() {
		thrustIndex = getPreferenceStore().getDefaultInt(P_PERFORMANCE);
		super.performDefaults();
		updateUI();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.preference.IPreferencePage#performOk()
	 */
	public boolean performOk() {
		getPreferenceStore().setValue(P_PERFORMANCE, thrustIndex);
		return true;
	}

	static public IPaintableManager createPaintableManager() {
		return J2DRegistry.createPaintableManager(
			J2DPlugin.getDefault().getPreferenceStore().getInt(P_PERFORMANCE));
	}
}
