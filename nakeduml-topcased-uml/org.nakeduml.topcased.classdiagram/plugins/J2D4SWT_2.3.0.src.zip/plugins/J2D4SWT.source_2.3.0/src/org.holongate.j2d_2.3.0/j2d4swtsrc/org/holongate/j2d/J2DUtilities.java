/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

/**
 * J2DUtilities defines some handy conversion routines between SWT Point and
 * Java2D Point2D classes.
 * 
 * @author Christophe Avare
 * @version $Revision: 1.3 $
 */
public final class J2DUtilities {

	public static Point toPoint(Point2D p) {
		return new Point((int) p.getX(), (int) p.getY());
	}

	public static Point2D toPoint2D(int x, int y) {
		return new Point2D.Double(x, y);
	}

	public static Point2D toPoint2D(Point p) {
		return new Point2D.Double(p.x, p.y);
	}

	public static Rectangle2D toRectangle2D(Rectangle r) {
		return new Rectangle2D.Double(r.x, r.y, r.width, r.height);
	}

	public static Rectangle toRectangle(Rectangle2D r2d) {
		java.awt.Rectangle r = r2d.getBounds();
		return new Rectangle(r.x, r.y, r.width, r.height);
	}

	/**
	 * A utility method to convert an SWT Color to an AWT one.
	 * 
	 * @param c
	 *            The SWT Color
	 * @return An equivalent AWT Color
	 */
	public static java.awt.Color toAWTColor(Color c) {
		return new java.awt.Color(c.getRed(), c.getGreen(), c.getBlue());
	}

	/**
	 * A utility method to convert an AWT Color to an SWT one.
	 * The default display is used.
	 * Resource disposal should be performed by the caller.
	 * 
	 * @param c
	 *            The AWT Color
	 * @return An equivalent SWT Color
	 */
	public static Color toSWTColor(java.awt.Color c) {
		return new Color(Display.getDefault(),c.getRed(), c.getGreen(), c.getBlue());
	}
}
