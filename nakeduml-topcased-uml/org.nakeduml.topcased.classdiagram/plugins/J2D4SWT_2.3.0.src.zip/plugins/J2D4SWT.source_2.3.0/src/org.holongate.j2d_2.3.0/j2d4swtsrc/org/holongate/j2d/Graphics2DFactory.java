/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Control;

/**
 * This class is the root of all the Graphics2D factories the Java2D for SWT
 * framework can use.
 * <p>
 * A Graphics2D factory is used to create Graphics2D objects bound to a given
 * SWT Control and perform the necessary work to make the Java2D calls issued
 * through the Graphics2D visible on the Control surface.
 * </p>
 * <p>
 * Each factory is given a 'size' representing the maximum extend any drawing
 * can have using this factory. This size is not really a constraint (one can
 * try to draw outside this area) but an indication of what pixels are
 * guaranteed to be drawn: this is also different from the visible area. The
 * size will usually be monitored by an outside process, for example to match
 * to control's size, and it is expected that each factory implementation
 * correctly adjust itself to satisfy any size change request.
 * </p>
 * <p>
 * Instances of derived classes are required to be registered in the
 * J2DRegistry for further use and have a suitable update() method
 * implementation.
 * </p>
 * <p>
 * This implementation gets a Graphics2D object from a BufferedImage.
 * </p>
 * 
 * @author Christophe Avare
 * @version $Revision: 1.5.2.1 $
 */
public abstract class Graphics2DFactory {
	/**
	 * The SWT Control this factory is bound
	 */
	private Control _control;

	/**
	 * The last requested size for this factory
	 */
	private Point size = new Point(0, 0);

	/**
	 * The buffered image used as the offscreen buffer for Java2D rendering.
	 */
	private BufferedImage offscreenImage;

	/**
	 * No argument constructor.
	 * <p>
	 * This no-arg public constructor is needed by the Eclipse plugin extension
	 * point mechanism to use this class as an executable extension.
	 * </p>
	 */
	public Graphics2DFactory() {
		super();
	}

	/**
	 * This non public constructor is usually called by the createFactory()
	 * method.
	 * <p>
	 * It is a good practice to explicitely put initialization code in
	 * constructors, even if they are indirectly called. The initial size is
	 * <b>not <b>set.
	 * </p>
	 * 
	 * @param control
	 *            A SWT Control widget, target of the rendering process
	 */
	protected Graphics2DFactory(final Control control) {
		this._control = control;
	}

	/**
	 * Returns the control.
	 * 
	 * @return Control The control this factory is bound
	 */
	public Control getControl() {
		return _control;
	}

	/**
	 * Creates a new factory tied to a Control.
	 * <p>
	 * The control is used to obtain platform specific information, size of the
	 * client area, etc. Some implementations may also add listeners to the
	 * control to track resizing, disposal, ...
	 * </p>
	 * <p>
	 * This method is usually implemented as a call to the
	 * Graphics2DFactory(Control) constructor.
	 * </p>
	 * 
	 * @param control
	 *            A SWT Control widget, target of the rendering process
	 * @return A Graphics2DFactory suitable for this particular control
	 */
	abstract public Graphics2DFactory createFactory(final Control control);

	/**
	 * Creates a new Graphics2D object suitable for drawing on this Control.
	 * <p>
	 * A new Graphics2D object should be created each time this method is
	 * called. No special initialization is required, as only the caller have
	 * the necessary knowledge for its use. It is also the caller
	 * responsability to dispose of the returned objet, following the Eclipse
	 * platform resource management rules.
	 * </p>
	 * 
	 * @return A Graphics2D ready to be used.
	 */
	public Graphics2D createGraphics2D() {
		return offscreenImage.createGraphics();
	}

	/**
	 * The update operation should perform all the necessary work to display
	 * the Java2D drawings on the SWT control.
	 * 
	 * @param damaged
	 *            The rectangular damaged area given by the paint event
	 * @param gc
	 *            The SWT GC describing the receiving widget
	 */
	abstract public void update(final Rectangle damaged, final GC gc);

	/**
	 * Graphics2DFactory are resources following the paint and lifecycle of the
	 * target control.
	 * <p>
	 * This method is called when the control is disposed.
	 * </p>
	 */
	public void dispose() {
		_control = null;
		disposeOffscreenImage();
	}

	/**
	 * An internal cleanup method.
	 * <p>
	 * Because BufferedImages can consume vast amounts of memory, careful
	 * memory management is required.
	 * </p>
	 */
	private void disposeOffscreenImage() {
		if (offscreenImage != null) {
			offscreenImage.flush();
			offscreenImage = null;
		}
	}

	/**
	 * Sets the size of the painting area this factory must honor.
	 * <p>
	 * The actual size (of the offscreen image) must be equal or larger than
	 * the requested size.
	 * </p>
	 * <p>
	 * The offscreen image is immediately created to avoid some delay before
	 * the paint cycle starts.
	 * </p>
	 * 
	 * @param size
	 *            The requested size
	 */
	public void setSize(final Point size) {
		this.size.x = size.x;
		this.size.y = size.y;
		disposeOffscreenImage();
		offscreenImage = createBufferedImage(size.x, size.y);
	}

	/**
	 * Returns the image size (maximum drawable area) this factory can use.
	 * <p>
	 * Any drawing outside this area is not defined but must not raise any
	 * runtime exception.
	 * </p>
	 * 
	 * @return The current image size
	 */
	public Point getSize() {
		return new Point(size.x, size.y);
	}

	/**
	 * Extending classes should redefine this method to build the internal
	 * offscreen BufferedImage.
	 * <p>
	 * Default implementation returns a BufferedImage of type TYPE_INT_ARGB.
	 * This should be reasonable in most cases.
	 * </p>
	 * 
	 * @param w
	 *            The required image width
	 * @param h
	 *            The required image height
	 * @return A BufferedImage of type TYPE_INT_ARGB and (w,h) size
	 */
	protected BufferedImage createBufferedImage(int w, int h) {
		return new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
	}

	/**
	 * Returns the offscreen image.
	 * <p>
	 * Modifications made on this image will not be visible until a call to
	 * update().
	 * </p>
	 * 
	 * @return The BufferedImage used as the offscreen image
	 */
	public BufferedImage getOffscreenImage() {
		return offscreenImage;
	}

	/**
	 * Adjust the width and height of the region so that the
	 * rectangle does not lie outside the image bounds.
	 *
	 * @param region The region to trim
	 * @return true if the region covers the entire image
	 */
	protected boolean trimUpdateRegion(Rectangle region) {
		int imgWidth = offscreenImage.getWidth();
		if (region.x + region.width > imgWidth) {
			region.width = imgWidth - region.x;
		}
		int imgHeigth = offscreenImage.getHeight();
		if (region.y + region.height > imgHeigth) {
			region.height = imgHeigth - region.y;
		}
		return ((region.width == imgWidth) && (region.height == imgHeigth));
	}

	private static String[] os =
		{ "linux", "solaris", "macosx", "aix", "hpux", "qnx" };

	static protected void loadLibrary(String ws, String version) {
		for (int i = 0; i < os.length; i++) {
			String libName =
				"j2d-"
					+ ws
					+ "-"
					+ os[i]
					+ "-"
					+ System.getProperty("os.arch")
					+ "-"
					+ version;
			try {
				J2DRegistry.printMessage("Trying to load", libName);
				System.loadLibrary(libName);
				J2DRegistry.printMessage(
					"Native library " + libName + " loaded.",
					null);
				return;
			} catch (Error e) {
			}
		}
		J2DRegistry.printMessage(
			"No native library found for this platform!",
			null);
		throw new UnsatisfiedLinkError();
	}
}