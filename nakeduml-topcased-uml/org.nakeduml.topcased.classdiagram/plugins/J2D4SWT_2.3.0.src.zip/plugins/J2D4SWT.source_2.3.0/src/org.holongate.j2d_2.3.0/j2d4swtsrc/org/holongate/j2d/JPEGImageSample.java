/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.FileInputStream;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.widgets.Control;

import com.sun.image.codec.jpeg.JPEGCodec;

/**
 * A very small IPaintable that display a JPEG image from a file.
 * <br>
 * <b>This implementation uses classes from the com.sun.image.codec packages,
 * I hope this is does not break portability!</b> I just don't want to use
 * an intermediaite SWT Image for that purpose, nor any AWT or Toolkit function
 * that will start the AWT event queue.
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1 $
 */
public class JPEGImageSample implements IPaintable {
	private BufferedImage image;

	public JPEGImageSample(String file) {
		try {
			image =
				JPEGCodec
					.createJPEGDecoder(new FileInputStream(file))
					.decodeAsBufferedImage();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void paint(Control control, Graphics2D g2d) {
		if (image == null) {
			return;
		}
		g2d.drawRenderedImage(image, null);
	}

	/**
	 * @see org.holongate.j2d.IPaintable#redraw(Control, GC)
	 */
	public void redraw(Control control, GC gc) {
	}

	/**
	 * Returns the image.
	 * @return BufferedImage
	 */
	public BufferedImage getImage() {
		return image;
	}

	/* (non-Javadoc)
	 * @see org.holongate.j2d.IPaintable#getBounds(org.eclipse.swt.widgets.Control)
	 */
	public Rectangle2D getBounds(Control control) {
		return new Rectangle2D.Double(0,0,image.getWidth(),image.getHeight());
	}

}