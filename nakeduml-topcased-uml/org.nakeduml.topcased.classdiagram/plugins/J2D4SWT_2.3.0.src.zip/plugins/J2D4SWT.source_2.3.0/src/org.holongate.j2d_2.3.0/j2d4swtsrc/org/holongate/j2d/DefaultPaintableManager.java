/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import java.awt.geom.AffineTransform;

import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Control;

/**
 * The default paintable manager behaves exactly as a double buffer of the
 * whole canvas.
 * <p>
 * No other operations than direct image transformations are applied. This
 * paintable manager only uses the Java2D capabilities to transform the image.
 * It consumes less memory than other managers but have no performance gains
 * above standard Java2D.
 * </p>
 * <p>
 * This manager tracks its control size and repaint events: The graphics
 * factory size is kept in sync with the control size and the default paint
 * mode is PAINT_DAMAGED. The applyTransform() call forces a PAINT_ALL event to
 * refresh the whole image.
 * </p>
 * <p>
 * The parent composite layout will define the size of the graphics factory. If
 * there is no layout, a FillLayout is set on the parent composite.
 * </p>
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1.2.1 $
 */
public class DefaultPaintableManager extends AbstractPaintableManager {
	private ControlAdapter ctrlAdapter;
	private PaintListener paintListener;

	/**
	 * Creates a new manager for the given canvas.
	 */
	public DefaultPaintableManager() {
		super();
		ctrlAdapter = new ControlAdapter() {
			public void controlResized(ControlEvent e) {
				IPaintableCanvas c = getPaintableCanvas();
				Point d = c.getControl().getSize();
				if ((d.x > 0) && (d.y > 0)) {
					c.getGraphics2DFactory().setSize(d);
					setSize(d);
					c.repaint();
				}
			}
		};
		paintListener = new PaintListener() {
			public void paintControl(final PaintEvent event) {
				getPaintableCanvas().applyPaintEvent(event);
			}
		};
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#attach(org.holongate.j2d.IPaintableCanvas)
	 */
	public void attach(IPaintableCanvas paintable) {
		detach();
		this.canvas = paintable;
		paintable.setDefaultPaintMode(IPaintableCanvas.PAINT_DAMAGED);
		Control ctrl = paintable.getControl();
		if (ctrl.getParent().getLayout() == null) {
			ctrl.getParent().setLayout(new FillLayout());
		}
		ctrl.addPaintListener(paintListener);
		ctrl.addControlListener(ctrlAdapter);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#detach()
	 */
	public void detach() {
		if (canvas != null) {
			canvas.getControl().removePaintListener(paintListener);
			canvas.getControl().removeControlListener(ctrlAdapter);
			canvas = null;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#setInitialTransform(java.awt.geom.AffineTransform)
	 */
	public void setInitialTransform(AffineTransform t) {
		super.setInitialTransform(t);
		if (immediateMode)
			applyTransform();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#setOrigin(int, int)
	 */
	public void setOrigin(int x, int y) {
		super.setOrigin(x, y);
		if (immediateMode)
			applyTransform();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#setRotationAngle(double)
	 */
	public void setRotationAngle(double angle) {
		super.setRotationAngle(angle);
		if (immediateMode)
			applyTransform();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#setRotationCenter(int, int)
	 */
	public void setRotationCenter(int rx, int ry) {
		super.setRotationCenter(rx, ry);
		if (immediateMode)
			applyTransform();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#setScale(double)
	 */
	public void setScale(double s) {
		super.setScale(s);
		if (immediateMode)
			applyTransform();
	}

	/**
	 * Forces a transform computation and starts a full paint refresh.
	 * <p>
	 * The net effect is the image being fully redisplayed given the current
	 * transformation parameters.
	 * </p>
	 */
	public void applyTransform() {
		immediateMode = true;
		updateTransform();
		getPaintableCanvas().repaint();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#translate(int, int)
	 */
	public void translate(int dx, int dy) {
		super.translate(dx, dy);
		if (immediateMode)
			applyTransform();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#reset()
	 */
	public void reset() {
		super.reset();
		if (immediateMode)
			applyTransform();
	}
}
