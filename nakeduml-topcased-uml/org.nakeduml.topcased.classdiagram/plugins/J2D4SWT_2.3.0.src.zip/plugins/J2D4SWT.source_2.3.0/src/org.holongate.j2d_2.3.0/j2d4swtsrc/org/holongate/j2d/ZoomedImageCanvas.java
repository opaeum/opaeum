/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Slider;

/**
 * This control is a composite displaying an image (through a JPEGImageSample
 * paintable) an compute a suitable zoom transformation knowning the zoom
 * factor. <br>A SWT Scale component is used to change the zoom factor. Note
 * that only standard SWT controls and laytout capabilties. <br>This control
 * is used in the preference page to illustrate the image interpolation method
 * effects.
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1.2.1 $
 */
public class ZoomedImageCanvas extends J2DCanvas {
	private static final int MIN_ZOOM = 1;
	private static final int MAX_ZOOM = 800;

	private Slider slider;
	private JPEGImageSample painter;
	private ZoomSelector currentSelector;

	/**
	 * Populates the composite with the scale control and associates a suitable
	 * selection listener to respond to user interaction.
	 */
	public ZoomedImageCanvas(Composite parent, int style, String file) {
		super(parent, style, new JPEGImageSample(file));
		painter = (JPEGImageSample) getPaintable();
		GridLayout gl = new GridLayout();
		gl.marginHeight = 2;
		gl.marginWidth = 2;
		setLayout(gl);
		addSlider();
		addMenu();
		addControlListener(new ControlAdapter() {
			public void controlResized(ControlEvent e) {
				Point s = getSize();
				if ((s.x != 0) && (s.y != 0)) {
					updateImage();
				}
			}
		});
	}

	/**
	 * Compute the transformation by applying the current zoom factor. <br>A
	 * suitable translation is also computed to keep the image centered on the
	 * display area.
	 */
	private void updateImage() {
		double s =
			(currentSelector == null)
				? slider.getSelection() / 100.0
				: currentSelector.getScale();
		Point size = getSize();
		int imWidth = painter.getImage().getWidth();
		int imHeight = painter.getImage().getHeight();
		int dx = (int) (0.5 * (size.x - s * imWidth));
		int dy = (int) (0.5 * (size.y - s * imHeight));
		getPaintableManager().setImmediateMode(false);
		getPaintableManager().reset();
		getPaintableManager().setScale(s);
		getPaintableManager().setOrigin(dx, dy);
		getPaintableManager().applyTransform();
	}

	private void addSlider() {
		slider = new Slider(this, SWT.HORIZONTAL);
		slider.setToolTipText("Change the zoom factor");
		slider.setMinimum(MIN_ZOOM);
		slider.setMaximum(MAX_ZOOM + MIN_ZOOM);
		slider.setPageIncrement(100);
		slider.setSelection(100);
		GridData gd = new GridData();
		gd.verticalAlignment = GridData.END;
		gd.horizontalAlignment = GridData.FILL;
		gd.grabExcessHorizontalSpace = true;
		gd.grabExcessVerticalSpace = true;
		slider.setLayoutData(gd);
		slider.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				currentSelector = null;
				updateImage();
			}
		});
	}

	private void addMenu() {
		Menu popup = new Menu(this);
		addItem(800, popup, "800%");
		addItem(400, popup, "400%");
		addItem(200, popup, "200%");
		addItem(100, popup, "100%");
		addItem(75, popup, "75%");
		addItem(50, popup, "50%");
		addItem(25, popup, "25%");
		addItem(0, popup, "fit to window");
		setMenu(popup);
	}

	private class ZoomSelector extends SelectionAdapter {
		private int z;
		public ZoomSelector(int z) {
			this.z = z;
		}
		public void widgetSelected(SelectionEvent e) {
			slider.setSelection((int) (getScale() * 100));
			currentSelector = this;
			updateImage();
		}
		public double getScale() {
			if (z != 0) {
				return z / 100.0;
			}
			double ih = painter.getImage().getHeight();
			double iw = painter.getImage().getWidth();
			Point s = getSize();
			return Math.min(s.x / iw, s.y / ih);
		}
	}

	private MenuItem addItem(int z, Menu m, String label) {
		MenuItem mi = new MenuItem(m, SWT.RADIO);
		mi.setText(label);
		ZoomSelector selector = new ZoomSelector(z);
		if (z == 0) {
			mi.setSelection(true);
			currentSelector = selector;
		}
		mi.addSelectionListener(selector);
		return mi;
	}
}