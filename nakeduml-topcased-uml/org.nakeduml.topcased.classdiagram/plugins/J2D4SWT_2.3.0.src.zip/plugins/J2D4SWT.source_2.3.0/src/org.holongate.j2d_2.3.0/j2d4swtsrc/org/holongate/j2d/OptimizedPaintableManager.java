/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Point;

/**
 * An optimized paintable manager makes translations directly on the control to accelarate
 * image displacements <br>
 * This paintable manager internally synchronizes the graphics2d factory size to the
 * transformed image size. This image is fully painted onto the canvas and translations
 * are "simulated" by changing the origin of the canvas inside its parent. <br>
 * There is some limitations when using this paintable manager:
 * <ul>
 * <li>If the (transformed) image is too large, some out of memory error may occur,</li>
 * <li>when the scale is changed, the whole paintable is repainted, not only the visible
 * part,</li>
 * <li>The parent composite must not have any layout so that the canvas size is never
 * changed,</li>
 * <li>The SWT Control.setLocation() call may or may not generate paint events depending
 * on the underlying window system (no event on windows, following the retain_background
 * hint on X11).</li>
 * </ul>
 * Given those limitations, this manager gives the best performance on all platforms.
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1.2.2 $
 */
public class OptimizedPaintableManager extends AbstractPaintableManager {
	private static final Point2D ZERO = new Point2D.Double(0, 0);
	private PaintListener paintListener;

	/**
	 * Creates a new manager.
	 * <p>
	 * The constructor main purpose is to attach a paint listener to force the event
	 * parameters to cover the full control client area. This is required because some
	 * platforms (most notably windows) do not generate correct paint events when the
	 * control has been moved or resized.
	 * </p>
	 */
	public OptimizedPaintableManager() {
		super();
		paintListener = new PaintListener() {
			public void paintControl(final PaintEvent event) {
				IPaintableCanvas c = getPaintableCanvas();
				//FIXME: windows workaround!
				// The SWT framework does not generate paint events (at least
				// on Windows platforms)
				// when the control is moved, only when resized.
				// So we have to 'make up' the event to cover the whole control
				// in case a full repaint is asked for.
				if (canvas.getPaintMode() == IPaintableCanvas.PAINT_ALL) {
					Point d = c.getControl().getSize();
					event.x = event.y = 0;
					event.width = d.x;
					event.height = d.y;
				}
				c.applyPaintEvent(event);
			}
		};
	}

	public void attach(IPaintableCanvas paintable) {
		detach();
		this.canvas = paintable;
		paintable.setDefaultPaintMode(IPaintableCanvas.PAINT_DAMAGED);
		paintable.getControl().getParent().setLayout(null);
		paintable.getControl().addPaintListener(paintListener);
		applyTransform();
	}

	private void setSizeFromPaintable() {
		Rectangle2D b = canvas.getPaintable().getBounds(canvas.getControl());
		setSize(new Point((int) b.getWidth(), (int) b.getHeight()));
	}

	public void detach() {
		if (canvas != null) {
			canvas.getControl().removePaintListener(paintListener);
			canvas = null;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#setInitialTransform(java.awt.geom.AffineTransform)
	 */
	public void setInitialTransform(AffineTransform t) {
		super.setInitialTransform(t);
		if (immediateMode)
			applyTransform();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#setOrigin(int, int)
	 */
	public void setOrigin(int x, int y) {
		super.setOrigin(x, y);
		if (immediateMode)
			setCanvasOrigin();
	}

	private void setCanvasOrigin() {
		Point o = toUser(origin);
		Point z = toUser(ZERO);
		canvas.getControl().setLocation(o.x - z.x, o.y - z.y);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#setRotationAngle(double)
	 */
	public void setRotationAngle(double angle) {
		super.setRotationAngle(angle);
		if (immediateMode)
			applyTransform();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#setRotationCenter(int, int)
	 */
	public void setRotationCenter(int rx, int ry) {
		super.setRotationCenter(rx, ry);
		if (immediateMode)
			applyTransform();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#setScale(double, double)
	 */
	public void setScale(double s) {
		super.setScale(s);
		if (immediateMode)
			applyTransform();
	}

	/**
	 * Computes the necessary transformations and update the canvas origin inside its
	 * parent frame.
	 */
	public void applyTransform() {
		immediateMode = true;
		setSizeFromPaintable();
		updateTransform();
		Rectangle2D bounds = getTransformedBounds();
		int w = (int) bounds.getWidth();
		int h = (int) bounds.getHeight();
		canvas.getGraphics2DFactory().setSize(new Point(w, h));
		setCanvasOrigin();
		canvas.getControl().setSize(w, h);
		canvas.repaint();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#reset()
	 */
	public void reset() {
		super.reset();
		if (immediateMode)
			applyTransform();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.AbstractPaintableManager#updateTransform()
	 */
	protected void updateTransform() {
		super.updateTransform();
		try {
			Point2D o = transform.inverseTransform(ZERO, null);
			canvasTransform.translate(o.getX(), o.getY());
		} catch (NoninvertibleTransformException e) {
			e.printStackTrace();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#translate(int, int)
	 */
	public void translate(int dx, int dy) {
		super.translate(dx, dy);
		if (immediateMode) {
			updateTransform();
			setCanvasOrigin();
		}
	}

}
