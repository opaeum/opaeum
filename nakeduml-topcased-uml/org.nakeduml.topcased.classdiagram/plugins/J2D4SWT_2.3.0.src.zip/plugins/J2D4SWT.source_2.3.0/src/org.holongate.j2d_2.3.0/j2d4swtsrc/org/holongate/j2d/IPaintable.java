/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.widgets.Control;

/**
 * This interface merges the Java2D paint() and SWT redraw() operations.
 * <p>
 * A paint call is always issued <b>before</b> the redraw one: the intent is
 * to allow implementors to use the normal SWT redraw() repaint cycle as an
 * overlay of the Java2D drawings.
 * </p>
 * <p>
 * Because the drawing process is delegated to this interface, the overall
 * paint/draw code can be delegated to any object, not only SWT widgets or AWT
 * components: this should ease Java2D code reuse.
 * </p>
 * <p>
 * The actual paint/redraw cycle is controlled by another object, usually the
 * SWT widget (which is aware of the paintEvent requests).
 * </p>
 * <p>
 * <b>Implementation notes:</b> It is recommended that all the IPaintable
 * implementations are "target neutral", that is don't assume the method
 * arguments like Control, GC and Graphics2D are constant over time and thus
 * can be cached or used beforehand. Following this rule will allow for an
 * efficient sharing of paintables between many IPaintableCanvas instances and
 * an easy integration into many MVC frameworks.
 * </p>
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1 $
 */
public interface IPaintable {
	/**
	 * The paint operation is the Java2D drawing part of the rendering process.
	 * <p>
	 * This operation is named after the standard paint() method in the AWT
	 * framework.
	 * </p>
	 * <p>
	 * The passed-in Graphics2D has its clipping region set if necessary.
	 * </p>
	 * 
	 * @param control
	 *            The SWT Control that will display the drawings
	 * @param g2d
	 *            The Graphics2D context to use
	 */
	void paint(Control control, Graphics2D g2d);

	/**
	 * The redraw operation is the SWT drawing part of the rendering process.
	 * <p>
	 * This operation is named after the standard redraw() method in SWT.
	 * </p>
	 * <p>
	 * The passed-in GC has its clipping region set if necessary.
	 * </p>
	 * 
	 * @param control
	 *            The SWT Control that will display the drawings
	 * @param gc
	 *            The GC context to use
	 */
	void redraw(Control control, GC gc);

	/**
	 * Returns the "natural" bounding box of this paintable (before any
	 * tranformation is applied).
	 * <p>
	 * Coordinates are expressed in the user space (i.e. in the Control
	 * coordinate system).
	 * </p>
	 * <p>
	 * This method uses the Control parameter mainly when it is required that
	 * its 'size' is kept in sync with the control's size.
	 * </p>
	 * 
	 * @param control
	 *            The Control this IPaintable should use
	 * @return The bounding box of this paintable
	 */
	public Rectangle2D getBounds(Control control);
}