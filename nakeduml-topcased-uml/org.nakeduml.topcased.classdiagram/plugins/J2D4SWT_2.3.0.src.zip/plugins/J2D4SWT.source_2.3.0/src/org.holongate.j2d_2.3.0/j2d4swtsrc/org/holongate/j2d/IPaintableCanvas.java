/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import java.awt.Graphics2D;

import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.widgets.Control;

/**
 * An interface defining the minimum required operations a paintable canvas
 * must supports.
 * <p>
 * This interface will help many different implementations of Java2D aware
 * controls, not required by the framework at the moment, but useful when
 * extending existing or custom controls.
 * </p>
 * <p>
 * <b>Thread issues:</b><br>All the paint() methods must conform to the SWT
 * threading model by issuing paint requests from inside the SWT thread. The
 * best way to achieve this constraint is to rely either on the control
 * redraw() methods or, if necessary, by calling the Display.syncExec() or
 * Display.asyncExec() method passing a suitable Runnable. Failing to follow
 * those rules will generate runtime exceptions that are hard to track down.
 * </p>
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1.2.1 $
 */
public interface IPaintableCanvas {
	/**
	 * Paint mode bit requesting an IPaintable.paint() call.
	 */
	static final int FULL_CYCLE = 4;
	/**
	 * Paint mode bit requesting a Graphics2DFactory.update() call.
	 */
	static final int UPDATE_CYCLE = 2;
	/**
	 * Paint mode bit requesting an IPaintable.redraw() call.
	 */
	static final int OVERLAY_CYCLE = 1;

	/**
	 * Paint mode for a full cycle.
	 */
	static final int PAINT_ALL = FULL_CYCLE | UPDATE_CYCLE | OVERLAY_CYCLE;
	/**
	 * Paint mode to repair damaged areas on the widget (IPaintable.paint() not
	 * called).
	 */
	static final int PAINT_DAMAGED = UPDATE_CYCLE | OVERLAY_CYCLE;
	/**
	 * Paint mode to only redraw the SWT widget (overlay layer).
	 */
	static final int PAINT_OVERLAY = OVERLAY_CYCLE;

	/**
	 * Returns the Graphics2DFactory actually used.
	 * <p>
	 * Not a very interesting information for the moment: all the factories
	 * created by the registry are of the same type! But this may change in the
	 * future because it should be useful to build more specialized factories
	 * based on standard factories (with conversion contructors like the stream
	 * hierarchy).This should help to deal with tiled images, or file mapped
	 * buffered images: In all those cases, the "best" factory algorithm
	 * depends on the image to be displayed and not only on the runtime
	 * platform.
	 * </p>
	 * 
	 * @return The Graphics2DFactory actually used
	 */
	Graphics2DFactory getGraphics2DFactory();

	/**
	 * Returns the IPaintable used to perform drawings.
	 * <p>
	 * null should be considered a valid value.
	 * </p>
	 * 
	 * @return The IPaintable this canvas will use
	 * @see org.holongate.j2d.IPaintable
	 */
	IPaintable getPaintable();

	/**
	 * Returns the paintable manager to be used for the translate/rotate/scale
	 * operations.
	 * 
	 * @return The IPaintableManager associated with this IPaintableCanvas
	 * @see org.holongate.j2d.IPaintableManager
	 */
	IPaintableManager getPaintableManager();

	/**
	 * Sets the paintable manager to be used for the translate/rotate/scale
	 * operations.
	 * <p>
	 * The old manager parameters may be lost, depending on the new manager
	 * capabilities. If a paintable manager is already bound to the paintable
	 * canvas, its detach() method must be called.
	 * </p>
	 * 
	 * @param manager
	 *            The new IPaintableManager associated with this
	 *            IPaintableCanvas
	 */
	void setPaintableManager(IPaintableManager manager);

	/**
	 * Provides a hook to perform some special initializations on the
	 * Graphics2D before the rendering process starts.
	 * <p>
	 * The clipping area should be set <em>before</em> this method is called
	 * so that setting the transform will also recompute the clip shape.
	 * </p>
	 * 
	 * @param g2d
	 *            The Graphics2D object used for further rendering
	 */
	void initGraphics(Graphics2D g2d);

	/**
	 * This method can be called by clients to force a repaint process at a
	 * given stage.
	 * 
	 * @param mode
	 *            One of the PAINT_XXX paint mode to use
	 */
	void paint(int mode);

	/**
	 * This method can be called by clients to force a repaint process at a
	 * given stage.
	 * <p>
	 * This method simply records the paint mode to use and must issue a
	 * redraw() request on the SWT control with the remaining parameters.
	 * </p>
	 * 
	 * @param x
	 *            Left coordinate of the damaged rectangle
	 * @param y
	 *            Top coordinate of the damaged rectangle
	 * @param w
	 *            Width of the damaged rectangle
	 * @param h
	 *            Height of the damaged rectangle
	 * @param f
	 *            True if SWT children must be redrawn
	 * @param mode
	 *            One of the PAINT_XXX paint mode to use
	 */
	void paint(int x, int y, int w, int h, boolean f, int mode);

	/**
	 * Force a general repaint cycle with the PAINT_ALL mode on the whole
	 * widget area.
	 */
	void repaint();

	/**
	 * This method is used to define where the repaint cycle starts.
	 * <p>
	 * This paint mode becomes the paint mode after each paint event.
	 * </p>
	 * <p>
	 * This information is necessary given that many repaint events are
	 * "spontaneously"generated by the windowing system in response to widget
	 * visibility events. The standard cycle starts at PAINT_DAMAGED, but this
	 * value can be changed at any time to suit some special needs.
	 * </p>
	 * <p>
	 * IPaintableManagers are expected to manage the repaint mode in the most
	 * efficient way given the operation triggered.
	 * </p>
	 * 
	 * @param mode
	 *            One of the PAINT_XXX modes.
	 */
	void setDefaultPaintMode(int mode);

	/**
	 * Returns the current default paint mode.
	 * 
	 * @return The current default paint mode
	 */
	int getDefaultPaintMode();

	/**
	 * Returns the paint mode that will be applied to the next paint event.
	 * <p>
	 * This value is only useful when this method is called inside a paint
	 * listener. In this case, the returned value is accurate (the paint event
	 * is being processing).
	 * </p>
	 * 
	 * @return The paint mode which will be applied
	 */
	int getPaintMode();

	/**
	 * Returns the SWT control this IPaintableCanvas represents.
	 * <p>
	 * This object can be used to get additional information, or to add
	 * listeners to the control. If listeners are added to the control, they
	 * must be removed when the control is disposed in the dispose() method.
	 * </p>
	 * 
	 * @return The SWT Control this paintable canvas is bound.
	 */
	Control getControl();

	/**
	 * The cleanup() method of this interface plays the same role as its SWT
	 * counterpart dispose().
	 * <p>
	 * This method name is different from the usual dispose() because calling
	 * the Widget.dispose() by overriding this method from a dispose listener
	 * is not allowed. On the contrary, this method <i>will</i> be called
	 * from the dispose listener.
	 * </p>
	 * <p>
	 * In all cases, implementors should follow the same rules as the platform
	 * for resource disposal.
	 * </p>
	 */
	void cleanup();

	/**
	 * This method is called whenever a paint event must be applied to the
	 * paintable canvas. <br>This method can be overloaded by clients to
	 * change some behavior in the repaint process. The paint mode used is set
	 * by setDefaultPaintMode().
	 * 
	 * @param event
	 *            The paint event the canvas received
	 */
	void applyPaintEvent(PaintEvent event);

	/**
	 * This method is called whenever a paint event must be applied to the
	 * paintable canvas. <br>This method can be overloaded by clients to
	 * change some behavior in the repaint process. The paint mode used is
	 * passed as an argument.
	 * 
	 * @param event
	 *            The paint event the canvas received
	 * @param mode
	 *            The paint mode to use with this event
	 */
	void applyPaintEvent(PaintEvent event, int mode);

}
