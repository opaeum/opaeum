/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.PaletteData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Control;

/**
 * The SWT factory is platform independant and only relies on the SWT Image and
 * ImageData capabilities.
 * <p>
 * A suitable ImageData is build from the BufferedImage data then an SWT Image
 * is created and drawn on the SWT Control.
 * </p>
 * <p>
 * Because building an SWT image from a byte array is an SWT time-consuming
 * process this factory is only used to ensure the same portability as the SWT
 * framework. It is expected to have "honest" performances thanks to some
 * aggressive (and maybe SWT version dependant) optimizations (hypothesis are
 * in bold):
 * <ul>
 * <li>The buffered image used is of type <b>TYPE_4BYTE_ABGR</b></li>
 * <li>With this image type, the <b>byte buffer layout is the same for Java2D
 * and ImageData</b></li>
 * <li>Because the <b>ImageData.data field is left public</b>, under some
 * circumstances, the image data can be reused by only changing its buffer,
 * avoiding unecessary (and time consuming) <tt>setPixels()</tt> calls</li>
 * </ul>
 * </p>
 * <p>
 * This factory is used when no other one has been found for the runtime
 * platform.
 * </p>
 * 
 * @author Christophe Avare
 * @version $Revision: 1.2.2.2 $
 */
public class SWTGraphics2DFactory extends Graphics2DFactory {
	/** The SWT palette that maps the ABGR AWT image color model */
	private static final PaletteData palette =
		new PaletteData(0x000000FF, 0x0000FF00, 0x00FF0000);
	private Image swtImage;
	private ImageData imageData;
	private Point lastArea = new Point(0, 0);

	/**
	 * No argument constructor to make this class an executable extension.
	 */
	public SWTGraphics2DFactory() {
		super();
	}

	/**
	 * Internal constructor for SWTGraphics2DFactory used by the factory.
	 * 
	 * @param control
	 */
	protected SWTGraphics2DFactory(Control control) {
		super(control);
	}

	public Graphics2DFactory createFactory(Control control) {
		return new SWTGraphics2DFactory(control);
	}

	/**
	 * @see org.holongate.j2d.Graphics2DFactory#update(Rectangle,GC)
	 */
	public void update(Rectangle region, GC gc) {
		if ((region.width == 0) || (region.height == 0)) {
			return;
		}
		Point newArea = new Point(region.width, region.height);
		// Extract the sub image.
		// We act upon the raster instead of the image to preserve the data
		// model and band layout
		trimUpdateRegion(region);
		java.awt.Rectangle subImage =
			new java.awt.Rectangle(
				region.x,
				region.y,
				region.width,
				region.height);
		byte[] data =
			((DataBufferByte) getOffscreenImage()
				.getData(subImage)
				.getDataBuffer())
				.getData();
		// Reuse if possible the current image data structure
		if (!lastArea.equals(newArea)) {
			lastArea = newArea;
			imageData = new ImageData(region.width, region.height, 32, palette);
		}
		//Don't call setPixels() on image data, just change the image data
		// reference
		imageData.data = data;
		swtImage = new Image(getControl().getDisplay(), imageData);
		gc.drawImage(swtImage, region.x, region.y);
		swtImage.dispose();
		data = null;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.BufferedImageGraphics2DFactory#createBufferedImage(int,
	 *      int)
	 */
	protected BufferedImage createBufferedImage(int w, int h) {
		// A TYPE_4BYTE_ABGR image type will allow us to bypass the setPixels()
		// method
		// call in the ImageData structure because the AWT buffer and SWT image
		// data layout will be
		// the same.
		return new BufferedImage(w, h, BufferedImage.TYPE_4BYTE_ABGR);
	}
}
