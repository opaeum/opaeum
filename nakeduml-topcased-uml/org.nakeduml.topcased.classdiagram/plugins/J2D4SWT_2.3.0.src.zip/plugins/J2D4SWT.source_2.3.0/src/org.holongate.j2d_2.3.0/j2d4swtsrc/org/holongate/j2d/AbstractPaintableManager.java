/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.eclipse.swt.graphics.Point;

/**
 * A default paintable manager implementation.
 * <p>
 * This implementation does not generate actual repaint events, its sole
 * purpose is to ease the implementation of more specialized managers by
 * providing basic set/get method implementations and initialisations.
 * </p>
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1 $
 */
public abstract class AbstractPaintableManager implements IPaintableManager {
	protected boolean immediateMode;
	protected double s;
	protected double angle;
	protected Point2D origin;
	protected Point2D rotation;
	protected Point size;

	protected IPaintableCanvas canvas;
	protected AffineTransform transform;
	protected AffineTransform canvasTransform;
	protected AffineTransform initialTransform;

	/**
	 * Constructs a new paintable manager.
	 * <p>
	 * This constructor do only field initialization.
	 * <p>
	 * This constructor is protected so that only subclasses will expose a
	 * useful one.
	 * </p>
	 */
	protected AbstractPaintableManager() {
		super();
		initialTransform = new AffineTransform();
		transform = new AffineTransform();
		canvasTransform = new AffineTransform();
		size = new Point(0, 0);
		origin = new Point2D.Double();
		rotation = new Point2D.Double();
		internalReset();
	}

	/**
	 * Resets all the parameters to their default value, except the initial
	 * transform.
	 * <p>
	 * Subclasses should call this method first if overriden.
	 * </p>
	 */
	protected void internalReset() {
		immediateMode = true;
		transform.setToIdentity();
		canvasTransform.setToIdentity();
		origin.setLocation(0, 0);
		rotation.setLocation(0, 0);
		s = 1.0;
		angle = 0;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#getPaintableCanvas()
	 */
	public IPaintableCanvas getPaintableCanvas() {
		return canvas;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#setOrigin(int, int)
	 */
	public void setOrigin(int x, int y) {
		origin = toDevice(x, y);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#setScale(double)
	 */
	public void setScale(double s) {
		this.s = s;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#setRotationCenter(int, int)
	 */
	public void setRotationCenter(int rx, int ry) {
		rotation.setLocation(rx, ry);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#setRotationAngle(double)
	 */
	public void setRotationAngle(double angle) {
		this.angle = angle;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#setInitialTransform(java.awt.geom.AffineTransform)
	 */
	public void setInitialTransform(AffineTransform t) {
		if (t == null) {
			t = new AffineTransform();
		}
		initialTransform = t;
	}

	/**
	 * An internal method used to recompute the cached tranform.
	 * <p>
	 * The transform is computed in the following order:
	 * <ol>
	 * <li>apply initial transform</li>
	 * <li>apply rotation(rotation,angle)</li>
	 * <li>apply scaling(scale)</li>
	 * <li>apply translation(origin)</li>
	 * </ol>
	 * </p>
	 */
	protected void updateTransform() {
		transform.setTransform(initialTransform);
		transform.rotate(angle, rotation.getX(), rotation.getY());
		transform.scale(s, s);
		transform.translate(origin.getX(), origin.getY());
		canvasTransform.setTransform(transform);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#getTranform()
	 */
	public AffineTransform getTransform() {
		return new AffineTransform(transform);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#getSize()
	 */
	public Point getSize() {
		return new Point(size.x, size.y);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#getTransformedBounds()
	 */
	public Rectangle2D getTransformedBounds() {
		Rectangle2D.Double bounds =
			new Rectangle2D.Double(0, 0, size.x, size.y);
		return canvasTransform.createTransformedShape(bounds).getBounds2D();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#setSize(org.eclipse.swt.graphics.Point)
	 */
	public void setSize(Point size) {
		this.size.x = size.x;
		this.size.y = size.y;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#translate(int, int)
	 */
	public void translate(int dx, int dy) {
		/*
		 * Point o = toDevice(origin); o.x += dx; o.y += dy; setOrigin(o.x,
		 * o.y);
		 */
		origin.setLocation(origin.getX() + dx / s, origin.getY() + dy / s);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#reset()
	 */
	public void reset() {
		internalReset();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#toUser(Point2D)
	 */
	public Point toUser(Point2D p) {
		updateTransform();
		return J2DUtilities.toPoint(transform.transform(p, null));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#toDevice(int,int)
	 */
	public Point2D toDevice(int x, int y) {
		updateTransform();
		Point2D r = J2DUtilities.toPoint2D(x, y);
		try {
			return transform.inverseTransform(r, null);
		} catch (NoninvertibleTransformException e) {
			e.printStackTrace();
		}
		return r;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#toDevice(Point)
	 */
	public Point2D toDevice(Point p) {
		return toDevice(p.x, p.y);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#getInitialTransform()
	 */
	public AffineTransform getInitialTransform() {
		return new AffineTransform(initialTransform);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#getOrigin()
	 */
	public Point2D getOrigin() {
		return origin;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#getCanvasTransform()
	 */
	public AffineTransform getCanvasTransform() {
		return canvasTransform;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#getScale()
	 */
	public double getScale() {
		return s;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#init(org.holongate.j2d.IPaintableManager)
	 */
	public void init(IPaintableManager manager) {
		immediateMode = false;
		AbstractPaintableManager mgr = (AbstractPaintableManager) manager;
		initialTransform.setTransform(mgr.initialTransform);
		s = mgr.s;
		origin.setLocation(mgr.origin);
		rotation.setLocation(mgr.rotation);
		angle = mgr.angle;
		size.x = mgr.size.x;
		size.y = mgr.size.y;
		updateTransform();
		immediateMode = true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#getRotationCenter()
	 */
	public Point2D getRotationCenter() {
		return rotation;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#getRotationAngle()
	 */
	public double getRotationAngle() {
		return angle;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableManager#setImmediateMode(boolean)
	 */
	public void setImmediateMode(boolean b) {
		immediateMode = b;
	}
}
