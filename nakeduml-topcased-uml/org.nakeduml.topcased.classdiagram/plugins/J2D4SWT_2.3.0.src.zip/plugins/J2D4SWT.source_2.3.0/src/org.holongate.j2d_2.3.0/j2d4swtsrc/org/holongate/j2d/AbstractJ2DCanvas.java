/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import java.awt.Graphics2D;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

/**
 * The root of all the canvases that can display Java2D graphics.
 * <p>
 * An abstractJ2DCanvas is an SWT canvas that can use a Graphics2DFactory to
 * obtain a Graphics2D object and an IPaintable to render the Java2D and SWT
 * drawings. This component implements basic services that help designing paint
 * event handlers and paintable managers like:
 * <ul>
 * <li>Paint cycle management,</li>
 * <li>Graphic stuff initialization,
 * <li>SWT integration (control lifecycle, color synchronization).</li>
 * </ul>
 * All the SWT standard event handling can be performed on this class, while
 * standard Java2D or SWT drawings are performed through the IPaintable
 * interface. The SWT drawings are always performed on top (overlay) of this
 * image.
 * </p>
 * <p>
 * The SWT GC and Graphics2D foreground/background colors are synchronized to
 * ease migration from AWT/Java2D code.
 * </p>
 * <p>
 * Standard SWT style bits can be applied to this canvas, except that the
 * following style is always ORed with the provided one:
 * <p>
 * SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE | SWT.NO_MERGE_PAINTS
 * </p>
 * This style combinaison ensures that the painting process will be flicker
 * free and repaint events minimized to the smallest set of damaged areas.
 * </p>
 * <p>
 * <b>Some conception notes</b>
 * <ol>
 * <li>This Canvas obtains a working Graphics2D through the J2DRegistry.</li>
 * <li>The Graphics2D object is also initialized through the J2DRegistry: it
 * will then use the Java2D preferences when running inside the workbench.
 * </li>
 * <li>The Graphics2D transform is obtained from the paintable manager.</li>
 * <li>The redraw strategy is delegated to the applyPaintEvent() methods.
 * <li>Subclasses can then redefine a new strategy. The {@link TimedCanvas}
 * TimedCanvas</a> uses this method to compute the frame per second display
 * rate.</li>
 * </ol>
 * </p>
 * 
 * @author Christophe Avare
 * @version $Revision: 1.2 $
 */
public abstract class AbstractJ2DCanvas
	extends Canvas
	implements IPaintableCanvas {
	/**
	 * Effectively paints a rectangular area of the underlying offscreen image.
	 * <p>
	 * This method do all the pre-requisite initializations before calling the
	 * actual paint code:
	 * </p>
	 * <ol>
	 * <li>Creates the Graphics2D context</li>
	 * <li>Set the clip region to be the damaged rectangle</li>
	 * <li>Set the background color to be the widget color</li>
	 * <li>Clear the clipping region with that color</li>
	 * <li>Initialize the Graphics2D</li>
	 * <li>Call the actual paint method</li>
	 * <li>Dispose of the Graphics2D object</li>
	 * </ol>
	 * <p>
	 * After this call, the underlying offscreen image rectangle has been
	 * updated but is not visible until an update is performed through the
	 * graphics factory, issued as part of a paint event (with a PAINT_DAMAGED
	 * mode) on the SWT control.
	 * </p>
	 * 
	 * @param damaged
	 *            The damaged area to be painted.
	 */
	public void paint(Rectangle damaged) {
		// Get a new Graphics2D for the image.
		Graphics2D g2d = graphics2DFactory.createGraphics2D();
		// Set the clipping rectangle to the required region.
		java.awt.Rectangle clip =
			new java.awt.Rectangle(
				damaged.x,
				damaged.y,
				damaged.width,
				damaged.height);
		g2d.setClip(clip);
		// Initialize the Graphics2D transform and rendering hints
		initGraphics(g2d);
		// Fill the clip region (transformed in user space) with the background
		// colour.
		g2d.getClipBounds(clip);
		g2d.clearRect(clip.x, clip.y, clip.width, clip.height);
		// The paintable can now render the drawings using Java 2D.
		paintable.paint(this, g2d);
		// The Graphics2D must be disposed because there is no guarantee that
		// the factory will not change for the next call.
		g2d.dispose();
	}

	/**
	 * Required style bits for the underlying SWT Canvas
	 */
	public static int DEFAULT_STYLE =
		SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE | SWT.NO_MERGE_PAINTS;

	/**
	 * The widget foreground converted into a java.wt.Color object
	 */
	private java.awt.Color awtForegroundColor;

	/**
	 * The widget background converted into a java.wt.Color object
	 */
	private java.awt.Color awtBackgroundColor;

	/**
	 * The paint mode automatically set after a paint event is issued
	 */
	private int defaultPaintMode = PAINT_DAMAGED;

	/**
	 * The paint mode requested for a specific paint event.
	 * <p>
	 * Temporarily override the default paint mode
	 * </p>
	 */
	private int paintMode = PAINT_ALL;

	/**
	 * The Graphics2D factory used to create a Graphics2D object
	 */
	protected Graphics2DFactory graphics2DFactory;

	/**
	 * The paintable manager holding the rendering transform
	 */
	private IPaintableManager manager;

	/**
	 * The paintable used to render the drawings on this canvas
	 */
	private IPaintable paintable;

	/**
	 * Constructs an AbstractJ2DCanvas with the supplied arguments.
	 * <p>
	 * Default style is SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE |
	 * SWT.NO_MERGE_PAINTS.
	 * </p>
	 * 
	 * @param parent
	 *            The parent composite with which this canvas will be
	 *            associated.
	 * @param paintable
	 *            The IPaintable object responsible for the java2D and overlay
	 *            drawings
	 * @see org.eclipse.swt.SWT#NO_BACKGROUND
	 * @see org.eclipse.swt.SWT#NO_REDRAW_RESIZE
	 * @see org.eclipse.swt.SWT#NO_MERGE_PAINTS
	 */
	public AbstractJ2DCanvas(
		final Composite parent,
		final IPaintable paintable) {
		this(parent, DEFAULT_STYLE, paintable);
	}

	/**
	 * Constructs an AbstractJ2DCanvas with the supplied arguments.
	 * <p>
	 * The provided style is Ored with DEFAULT_STYLE, and a
	 * DefaultPaintableManager is provided.
	 * </p>
	 * 
	 * @param parent
	 *            The paren composite with which this canvas will be
	 *            associated.
	 * @param style
	 *            The canvas style to be used.
	 * @param paintable
	 *            The IPaintable object responsible for the java2D and overlay
	 *            drawings
	 * @see org.holongate.j2d.DefaultPaintableManager
	 */
	public AbstractJ2DCanvas(
		final Composite parent,
		final int style,
		final IPaintable paintable) {
		this(
			parent,
			DEFAULT_STYLE | style,
			paintable,
			new DefaultPaintableManager());
	}

	/**
	 * Constructs an AbstractJ2DCanvas with the supplied arguments.
	 * <p>
	 * A dispose listener is automatically attached to the canvas to dispose
	 * the graphics factory resources and detach the paintable manager from
	 * this widget.
	 * </p>
	 * 
	 * @param parent
	 *            The paren composite with which this canvas will be
	 *            associated.
	 * @param style
	 *            The canvas style to be used.
	 * @param paintable
	 *            The IPaintable object responsible for the java2D and overlay
	 *            drawings
	 * @param manager
	 *            The paintable manager to use
	 */
	public AbstractJ2DCanvas(
		final Composite parent,
		final int style,
		final IPaintable paintable,
		final IPaintableManager manager) {
		super(parent, style);
		this.paintable = paintable;
		// Creates an initial graphics factory
		graphics2DFactory = J2DRegistry.createGraphics2DFactory(this);
		// Synchronize the Java2D default colors with this widget one
		awtBackgroundColor = J2DUtilities.toAWTColor(getBackground());
		awtForegroundColor = J2DUtilities.toAWTColor(getForeground());
		// Dispose listener: detach manager and release graphics factory
		addDisposeListener(new DisposeListener() {
			public void widgetDisposed(DisposeEvent e) {
				cleanup();
			}
		});
		// Attach the paintable manager to this widget
		setPaintableManager(manager);
	}

	/**
	 * Sets the paintable manager to use.
	 * <p>
	 * If there was any paintable manager (different from the argument)
	 * attached to this canvas, it is first detached.
	 * </p>
	 * 
	 * @param newManager
	 *            The new paintable manager to use
	 * @throws IllegalArgumentException
	 *             if newManager is null
	 */
	public void setPaintableManager(IPaintableManager newManager) {
		if (newManager == null) {
			throw new IllegalArgumentException("Argument cannot be 'null'");
		}
		if (manager == null) {
			manager = newManager;
			manager.attach(this);
		} else if (manager != newManager) {
			manager.detach();
			manager = newManager;
			manager.attach(this);
			manager.init(newManager);
		}
	}

	/**
	 * Gets the current paintable manager.
	 * 
	 * @return The current paintable manager
	 */
	public IPaintableManager getPaintableManager() {
		return manager;
	}

	/**
	 * Intercepts the widget color change to cache the corresponding AWT color.
	 * <p>
	 * The awt color is used to clear the BufferedImage redraw area with the
	 * widget background color.
	 * </p>
	 * <p>
	 * No repaint event is issued, unless the SWT subsystem generates one. In
	 * the latter case, depending on the default paint mode value, the new
	 * color may (defaultPaintMode == PAINT_ALL) or not (defaultPaintMode !=
	 * PAINT_ALL) immediately be applied.
	 * </p>
	 * 
	 * @param c
	 *            The new widget background color
	 */
	public void setBackground(Color c) {
		awtBackgroundColor = J2DUtilities.toAWTColor(c);
		super.setBackground(c);
	}

	/**
	 * Intercepts the widget color change to cache the corresponding AWT color.
	 * <p>
	 * The awt color is used to set the Graphics2D paint color with the widget
	 * foreground color.
	 * </p>
	 * <p>
	 * No repaint event is issued, unless the SWT subsystem generates one. In
	 * the latter case, depending on the default paint mode value, the new
	 * color may (defaultPaintMode == PAINT_ALL) or not (defaultPaintMode !=
	 * PAINT_ALL) immediately be applied.
	 * </p>
	 * 
	 * @param c
	 *            The new widget foreground color
	 */
	public void setForeground(Color c) {
		awtForegroundColor = J2DUtilities.toAWTColor(c);
		super.setForeground(c);
	}

	/**
	 * Initializes the Graphics2D with the J2DRegistry hints and the current
	 * transform.
	 * <p>
	 * The current transform is obtained from the paintable manager, foreground
	 * and background Graphics2D colors are set accordingly to the widget
	 * values.
	 * </p>
	 * <p>
	 * Because the Graphics2D transform is set, any information like clipping
	 * that are expressed in user (screen) coordinates must be set before this
	 * call is issued.
	 * </p>
	 * 
	 * @param g2d
	 *            The Graphics2D object to initialize
	 */
	public void initGraphics(Graphics2D g2d) {
		J2DRegistry.initGraphics(g2d);
		g2d.setColor(awtForegroundColor);
		g2d.setBackground(awtBackgroundColor);
		g2d.setTransform(manager.getCanvasTransform());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableCanvas#paint(int, int, int, int,
	 *      boolean, int)
	 */
	public void paint(int x, int y, int w, int h, boolean f, int mode) {
		paintMode = mode;
		redraw(x, y, w, h, f);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableCanvas#paint(int)
	 */
	public void paint(int mode) {
		paintMode = mode;
		redraw();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableCanvas#repaint()
	 */
	public void repaint() {
		paint(IPaintableCanvas.PAINT_ALL);
	}

	/**
	 * Returns the paintable.
	 * 
	 * @return IPaintable
	 */
	public IPaintable getPaintable() {
		return paintable;
	}

	/**
	 * This method encapsulates the actual rendering process. <br>The default
	 * strategy is a basic implementation of a double buffer like process which
	 * has three stages, all optional but chained in that order:
	 * <OL>
	 * <LI>call IPaintable.paint() with a new Java2D graphic context</LI>
	 * <LI>call the Graphics2DFactory.update() to display the Java2D drawings
	 * onto the canvas (may use native calls)</LI>
	 * <LI>call IPaintable.redraw() to render the overlay layer with the
	 * component's graphic context</LI>
	 * </OL>
	 * Depending on the original repaint event, the redraw can start at one of
	 * this stage:
	 * <UL>
	 * <LI>SWT resize or paint event or paintImage() call: stage 1</LI>
	 * <LI>updateImage() call: stage 2</LI>
	 * <LI>SWT repaint event or redraw() call: stage 3</LI>
	 * </UL>
	 */
	public void applyPaintEvent(PaintEvent event) {
		applyPaintEvent(event, paintMode);
	}

	public void applyPaintEvent(PaintEvent event, int mode) {
		if (!isVisible() || (event.width == 0) || (event.height == 0)) {
			return;
		}

		// Build the damaged rectangle from the paint event
		Rectangle damaged =
			new Rectangle(event.x, event.y, event.width, event.height);

		//System.err.println("paint mode = " + mode + " - " + damaged);

		// The Java2D image has been marked as damaged, repaint it
		if ((mode & FULL_CYCLE) != 0) {
			paint(damaged);
		}
		// The SWT client area has been marked as damaged,
		// copy the Java2D image on it
		if ((mode & UPDATE_CYCLE) != 0) {
			graphics2DFactory.update(damaged, event.gc);
		}
		// The overlay layer must be redrawn
		if ((mode & OVERLAY_CYCLE) != 0) {
			paintable.redraw(this, event.gc);
			//event.gc.setForeground(getDisplay().getSystemColor(SWT.COLOR_RED));
			//event.gc.drawRectangle(damaged);
		}

		// Reset paintMode to its default value for the next call
		paintMode = defaultPaintMode;
	}

	/**
	 * Returns the current Graphics2DFactory.
	 * <p>
	 * Caller must not keep a reference to this object as it is destroyed and
	 * recreated if necessary.
	 * </P>
	 * 
	 * @return The current Graphics2DFactory
	 */
	public Graphics2DFactory getGraphics2DFactory() {
		return graphics2DFactory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableCanvas#getControl()
	 */
	public Control getControl() {
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableCanvas#setDefaultPaintMode(int)
	 */
	public void setDefaultPaintMode(int mode) {
		defaultPaintMode = mode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableCanvas#getDefaultPaintMode()
	 */
	public int getDefaultPaintMode() {
		return defaultPaintMode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableCanvas#getPaintMode()
	 */
	public int getPaintMode() {
		return paintMode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintableCanvas#cleanup()
	 */
	public void cleanup() {
		manager.detach();
		manager = null;
		graphics2DFactory.dispose();
		graphics2DFactory = null;
	}

	public void setPaintable(IPaintable paintable) {
		this.paintable = paintable;
	}

}