/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import java.awt.RenderingHints;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.preference.BooleanFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.RadioGroupFieldEditor;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

/**
 * The preference page for the Java2D rendering hints.
 * <p>
 * The preference page allows the selection of some of the Java2D rendering hints like
 * turning anti-aliasing on or off and selecting an interpolation method for bitmat image
 * scaling.
 * </p>
 * <p>
 * Changes to the hints are visible when the "Apply" button is pressed if the client is
 * listening to the property change events.
 * </p>
 * <p>
 * In any case, the new Java2D hints are registered in the J2DRegistry so that each time a
 * Graphics2D is passed to the J2DRegistry.initGraphics() method, it is initialized with
 * the current user preferences.
 * </p>
 * 
 * @author Christophe Avare
 * @version $Revision: 1.2.2.1 $
 */

public class RenderingPreferencePage extends FieldEditorPreferencePage implements
	IWorkbenchPreferencePage {
	/**
	 * The name of the anti-aliasing property in the preference store.
	 */
	public static final String P_AA = "prefs.rendering.aa";
	/**
	 * The name of the interpolation property in the preference store.
	 */
	public static final String P_INTERPOLATE = "prefs.rendering.interpolate";

	private RenderingPreferenceCanvas prefCanvas;

	/**
	 * The page description is set to the factory name, extracted from the extension
	 * <tt>name</tt> attribute.
	 * <p>
	 * This is useful to see at a glance which wrapper has been selected at runtime.
	 * </p>
	 */
	public RenderingPreferencePage() {
		super(GRID);
		setPreferenceStore(J2DPlugin.getDefault().getPreferenceStore());
		setDescription(J2DPlugin.getDefault().getConfigurationElement().getAttribute(
			"name"));
	}

	/**
	 * Creates the field editors.
	 */

	public void createFieldEditors() {
		addField(new BooleanFieldEditor(P_AA, J2DPlugin.getResourceString(P_AA),
			getFieldEditorParent()));
		addField(new RadioGroupFieldEditor(P_INTERPOLATE, J2DPlugin
			.getResourceString(P_INTERPOLATE), 1, new String[][]{
			{J2DPlugin.getResourceString("prefs.rendering.interpolate.bicubic"),
				"bicubic"},
			{J2DPlugin.getResourceString("prefs.rendering.interpolate.bilinear"),
				"bilinear"},
			{J2DPlugin.getResourceString("prefs.rendering.interpolate.neighbour"),
				"neighbour"}}, getFieldEditorParent(), true));
		String file = null;
		try {
			file = Platform.asLocalURL(
				J2DPlugin.getDefault().find(
					new Path(J2DPlugin.getResourceString("prefs.rendering.image"))))
				.getPath();
		} catch (IOException e) {
			e.printStackTrace();
		}
		prefCanvas = new RenderingPreferenceCanvas(getFieldEditorParent(), J2DPlugin
			.getResourceString("prefs.rendering.message"), file);
	}

	public void init(IWorkbench workbench) {
	}

	public boolean performOk() {
		boolean f = super.performOk();
		if (f) {
			updateHints(getPreferenceStore());
			prefCanvas.redraw();
		}
		return f;
	}

	/**
	 * An utility method to set the rendering hints in the J2DRegistry according to the
	 * values found into the given IPreferenceStore.
	 * 
	 * @param store
	 *            The preference store to use
	 */
	public static void updateHints(IPreferenceStore store) {
		Map hints = new HashMap(2);
		boolean aa = store.getBoolean(RenderingPreferencePage.P_AA);
		hints.put(RenderingHints.KEY_ANTIALIASING, aa
			? RenderingHints.VALUE_ANTIALIAS_ON
			: RenderingHints.VALUE_ANTIALIAS_OFF);
		String interpolate = store.getString(RenderingPreferencePage.P_INTERPOLATE);
		Object method = RenderingHints.VALUE_INTERPOLATION_BILINEAR;
		if (interpolate.equals("bicubic")) {
			method = RenderingHints.VALUE_INTERPOLATION_BICUBIC;
		} else if (interpolate.equals("neighbour")) {
			method = RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR;
		}
		hints.put(RenderingHints.KEY_INTERPOLATION, method);
		J2DRegistry.setHints(hints);
	}
}