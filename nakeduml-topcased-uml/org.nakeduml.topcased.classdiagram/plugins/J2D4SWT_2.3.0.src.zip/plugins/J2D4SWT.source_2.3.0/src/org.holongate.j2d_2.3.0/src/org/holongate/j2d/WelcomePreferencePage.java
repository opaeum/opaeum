/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

/**
 * A simple preference page with a welcome message.
 * <p>
 * The message contents it taken from the prefs.welcome.message plugin
 * property.
 * </p>
 * 
 * @author Christophe Avare
 * @version $Revision: 1.2.2.1 $
 */
public class WelcomePreferencePage
	extends PreferencePage
	implements IWorkbenchPreferencePage {

	public void init(IWorkbench workbench) {
		noDefaultAndApplyButton();
	}

	protected Control createContents(Composite parent) {
		Label l = new Label(parent, SWT.NONE);
		l.setText(J2DPlugin.getResourceString("prefs.welcome.message"));
		l.setLayoutData(new GridData(GridData.FILL_BOTH));
		return null;
	}
}
