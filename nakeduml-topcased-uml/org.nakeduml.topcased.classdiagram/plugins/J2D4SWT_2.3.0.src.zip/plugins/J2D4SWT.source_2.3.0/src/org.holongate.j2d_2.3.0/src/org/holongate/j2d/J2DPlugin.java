/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import java.util.ResourceBundle;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

/**
 * The J2D plugin is the main workbench entry point.
 * <p>
 * It provides the following services:
 * <ul>
 * <li>Persistence of the Java2D preferences</li>
 * <li>Extension point org.holongate.j2d.factories management</li>
 * </ul>
 * This plugin is ready to be internationalized through its descriptor resource bundle
 * (i.e. international strings are taken from the plugin_*.properties files).
 * </p>
 * 
 * @author Christophe Avare
 * @version $Revision: 1.5.2.2 $
 * @since 2.3.0 (OSGI runtime based)
 */
public class J2DPlugin extends AbstractUIPlugin {
	//The shared instance.
	private static J2DPlugin plugin;
	//The current platform matching string
	private static String platform;
	//Resource bundle.
	private static ResourceBundle resourceBundle;
	//Configuration element for this platform factory
	private IConfigurationElement element;

	public J2DPlugin() {
		super();
	}

	/**
	 * The plugin startup code does the following job:
	 * <ol>
	 * <li>Find all the well-known org.holongate.j2d.factory extensions</li>
	 * <li>Find which extension has a platform attribute matching the runtime descriptor
	 * </li>
	 * <li>Create the executable extension for the first matching extension and returns
	 * </li>
	 * </ol>
	 * If no suitable extension is found, a, exception is thrown and the plugin is
	 * disabled.
	 * 
	 * @throws CoreException
	 *             When there is no extension for the runtime platform.
	 */
	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;
		resourceBundle = Platform.getResourceBundle(getBundle());
		platform = Platform.getOS() + "." //$NON-NLS-1$
			+ Platform.getWS() + "." //$NON-NLS-1$
			+ Platform.getOSArch();
		//Factory reference for this platform
		Graphics2DFactory factory = null;
		IConfigurationElement defaultElement = null;
		// Find all the declared extensions
		IExtensionRegistry registry = Platform.getExtensionRegistry();
		IExtensionPoint point = registry.getExtensionPoint("org.holongate.j2d.factories"); //$NON-NLS-1$
		IExtension extensions[] = point.getExtensions();
		// Try to find which extension match the runtime platform
		for (int e = 0; e < extensions.length; e++) {
			IConfigurationElement[] elements = extensions[e].getConfigurationElements();
			try {
				for (int f = 0; f < elements.length; f++) {
					String extensionPlatform = elements[f].getAttribute("platform"); //$NON-NLS-1$
					//Record the platform independant extension for further
					// use
					if (extensionPlatform.equals("all")) { //$NON-NLS-1$
						defaultElement = elements[f];
						continue;
					} else if (extensionPlatform.equals(platform)) {
						// Record this element as the working one
						element = elements[f];
						// If the extension matches the runtime platform,
						// try to creates the wrapper object from the class
						// attribute
						factory = (Graphics2DFactory) elements[f]
							.createExecutableExtension("class"); //$NON-NLS-1$
						// Log the info
						getLog().log(
							new Status(Status.INFO, getBundle().getSymbolicName(), 0,
								element.getAttribute("name") //$NON-NLS-1$
									+ ": " //$NON-NLS-1$
									+ getResourceString("factory.installed"), //$NON-NLS-1$
								null));
						break;
					}
				}
			} catch (Throwable ex) {
				// Factory creation failed at some point, maybe because of a
				// configuration mistake.
				// Report the fact and try the next extension
				getLog().log(
					new Status(Status.ERROR, getBundle().getSymbolicName(), 1, element
						.getAttribute("name") //$NON-NLS-1$
						+ ": " //$NON-NLS-1$
						+ getResourceString("factory.failed"), //$NON-NLS-1$
						ex));
			}
		}
		// If all extensions have been processed but there is no suitable one,
		// Use the default one.
		if (factory == null) {
			element = defaultElement;
			factory = (Graphics2DFactory) defaultElement
				.createExecutableExtension("class"); //$NON-NLS-1$
			getLog().log(
				new Status(Status.INFO, getBundle().getSymbolicName(), 0,
					getResourceString("factory.default"), //$NON-NLS-1$
					null));
		}
		// Register the plat-form factory
		J2DRegistry.registerFactory(factory);
		// Set the rendering hints with the current values fom the preference
		// store
		RenderingPreferencePage.updateHints(getPreferenceStore());
	}

	/**
	 * Returns the shared instance.
	 * 
	 * @return J2DPlugin The worskpace plugin instance
	 */
	public static J2DPlugin getDefault() {
		return plugin;
	}

	/**
	 * Returns a string from the resource bundle, knowing its key. Note: the generated
	 * code is not strong enough because a NullPointerException is raised if there is no
	 * resource bundle, instead of 'key' to be returned for consistency.
	 * 
	 * @return The string from the plugin's resource bundle, or 'key' if not found.
	 */
	public static String getResourceString(String key) {
		try {
			return resourceBundle.getString(key);
		} catch (Exception e) {
			return key;
		}
	}

	/**
	 * Returns the plugin's resource bundle. Note that for this plugin, the resource
	 * bundle is the same as the plugin descriptor resource bundle.
	 * 
	 * @return The plugin's resource bundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * Returns the selected configuration element.
	 * 
	 * @return The configuration element found during the startup process.
	 */
	public IConfigurationElement getConfigurationElement() {
		return element;
	}

	/**
	 * Sets the default values of the preferences:
	 * <ul>
	 * <li>anti-aliasing = true</li>
	 * <li>interpolation = bilinear</li>
	 * <li>performance level = 1 (translate optimized)
	 * </ul>
	 * 
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#initializeDefaultPreferences(org.eclipse.jface.preference.IPreferenceStore)
	 */
	protected void initializeDefaultPreferences(IPreferenceStore store) {
		store.setDefault(RenderingPreferencePage.P_AA, true);
		store.setDefault(RenderingPreferencePage.P_INTERPOLATE, "bilinear"); //$NON-NLS-1$
		store.setDefault(PerformancePreferencePage.P_PERFORMANCE, 1);
	}
}