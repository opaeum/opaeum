/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Control;

/**
 * An sample IPaintable implementation for testing purposes that can be used as
 * a test class and a coding example. <br>It displays three transparent
 * circles (red, green and blue) rotating around the canvas center over a
 * stoked text filled with a magenta-yellow (!!!!) gradient and a grey drop
 * shadow: This should exercice all the major functionnalities of Java2D. <br>
 * Each paint() call rotates the circles 1� around the center.
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1.2.1 $
 */
public class J2DSamplePaintable implements IPaintable {
	private final static Color red = new Color(255, 0, 0, 128);
	private final static Color green = new Color(0, 255, 0, 128);
	private final static Color blue = new Color(0, 0, 255, 128);
	private final static Font font =
		new java.awt.Font(
			"Helvetica",
			java.awt.Font.ITALIC | java.awt.Font.BOLD,
			18);

	private final AffineTransform tr = new AffineTransform();
	private String message;
	public double angle = 0;
	private double SINA;
	private double COSA;
	private GlyphVector gv;
	private Shape outline;
	private GradientPaint gp;

	public J2DSamplePaintable(String message) {
		this.message = message;
	}

	public void paint(Control control, Graphics2D g2d) {
		Point size = control.getSize();
		if (gv == null) {
			gv = font.createGlyphVector(g2d.getFontRenderContext(), message);
			Rectangle2D bounds = gv.getLogicalBounds();
			outline = gv.getOutline(0, 0);
			gp =
				new GradientPaint(
					0,
					0,
					Color.black,
					(float) bounds.getWidth(),
					0,
					Color.white);
		}

		double s = Math.min(size.x, size.y);
		double R = s / 5;
		double cx = size.x / 2.0 - 1.5 * R;
		double cy = size.y / 2.0 - 1.5 * R;
		Shape circle = new Ellipse2D.Double(0, 0, 3 * R, 3 * R);
		SINA = Math.sin(Math.toRadians(angle));
		COSA = Math.cos(Math.toRadians(angle));
		tr.setToTranslation(cx + R * SINA, cy + R * COSA);
		g2d.setTransform(tr);
		g2d.setColor(red);
		g2d.fill(circle);
		SINA = Math.sin(Math.toRadians(angle + 120));
		COSA = Math.cos(Math.toRadians(angle + 120));
		g2d.setColor(green);
		tr.setToTranslation(cx + R * SINA, cy + R * COSA);
		g2d.setTransform(tr);
		g2d.fill(circle);
		SINA = Math.sin(Math.toRadians(angle + 240));
		COSA = Math.cos(Math.toRadians(angle + 240));
		g2d.setColor(blue);
		tr.setToTranslation(cx + R * SINA, cy + R * COSA);
		g2d.setTransform(tr);
		g2d.fill(circle);

		Rectangle2D bbox = outline.getBounds2D();
		s = size.x / (bbox.getWidth() + 8);
		tr.setToTranslation(0, (size.y + bbox.getHeight()) / 2.0);
		tr.scale(s, s);
		g2d.setTransform(tr);
		g2d.setPaint(Color.gray);
		g2d.translate(8 / s, 8 / s);
		g2d.fill(outline);
		g2d.translate(-8 / s, -8 / s);
		g2d.setPaint(gp);
		g2d.fill(outline);
	}

	/*
	 * (non-javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintable#redraw(Control,GC)
	 */
	public void redraw(Control control, GC gc) {}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.j2d.IPaintable#getBounds(org.eclipse.swt.widgets.Control)
	 */
	public Rectangle2D getBounds(Control control) {
		return J2DUtilities.toRectangle2D(control.getBounds());
	}
}