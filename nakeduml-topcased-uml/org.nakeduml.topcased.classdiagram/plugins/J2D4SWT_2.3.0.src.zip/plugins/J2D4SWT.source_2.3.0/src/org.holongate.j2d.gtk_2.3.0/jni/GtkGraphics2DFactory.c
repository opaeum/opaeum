#include "org_holongate_j2d_gtk_GtkGraphics2DFactory.h"
#include "gtk/gtk.h"

/*
 * Class:     org_holongate_j2d_gtk_GtkGraphics2DFactory
 * Method:    gdk_draw_rgb_32_image
 * Signature: (IIIIII[II)V
 */
JNIEXPORT void JNICALL Java_org_holongate_j2d_gtk_GtkGraphics2DFactory_gdk_1draw_1rgb_132_1image
  (JNIEnv *env, jclass that, jint widget, jint gc, jint xDest, jint yDest, jint width, jint height, jintArray data, jint stride) {

	GdkDrawable *drawable = ((GtkWidget *)widget)->window;
	jint* lpvBits = (*env)->GetPrimitiveArrayCritical(env, data, 0);

	gdk_draw_rgb_32_image(
			drawable,
			(GdkGC *)gc,
			(gint)xDest,(gint)yDest,
			(gint)width,(gint)height,
			GDK_RGB_DITHER_NONE,
			(guchar *)lpvBits,
			(gint)stride
		);

	// Array is released without writing back data (JNI_ABORT)
	(*env)->ReleasePrimitiveArrayCritical(env, data, lpvBits, JNI_ABORT);
}
