/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.j2d.win32;

import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Control;
import org.holongate.j2d.Graphics2DFactory;

/**
 * A Graphics2DFactory with native acceleration for the Win32 platform. <br>
 * The buffered image type is set to BufferedImage.TYPE_INT_ARGB, and The image width is 4
 * bytes aligned as required by the SetDIBitsToDevice Win32 API.
 * 
 * @author Christophe Avare
 * @version $Revision: 1.7.2.1 $
 */
public class Win32Graphics2DFactory extends Graphics2DFactory {

	static {
		System.loadLibrary("j2d-win32-win32-x86-2.0.0");
	}

	/**
	 * Constructor for Win32Graphics2DFactory.
	 */
	public Win32Graphics2DFactory() {
		super();
	}

	/**
	 * Constructor for Win32Graphics2DFactory.
	 * 
	 * @param owner
	 *            The control used as the drawing target.
	 */
	public Win32Graphics2DFactory(Control owner) {
		super(owner);
	}

	public Graphics2DFactory createFactory(Control control) {
		return new Win32Graphics2DFactory(control);
	}

	/**
	 * Compute the best image size for this implementation. win32: image width must be
	 * aligned on a 4 byte boundary
	 * 
	 * @param width
	 *            The image width
	 * @param height
	 *            The image height
	 * @return A new, possibly corrected image size
	 */
	static private Point getBestImageSize(int width, int height) {
		Point bestSize = new Point(width, height);
		final int alignment = width % 4;
		if (alignment != 0) {
			bestSize.x += 4 - alignment;
		}
		return bestSize;
	}

	/**
	 * @see org.holongate.j2d.Graphics2DFactory#createBufferedImage(int, int)
	 */
	protected BufferedImage createBufferedImage(int width, int height) {
		Point bestSize = getBestImageSize(width, height);
		return new BufferedImage(bestSize.x, bestSize.y, BufferedImage.TYPE_INT_ARGB);
	}

	/**
	 * @see org.holongate.j2d.Graphics2DFactory#update(Rectangle,GC)
	 */
	public void update(Rectangle region, GC gc) {
		BufferedImage image = getOffscreenImage();
		Rectangle bounds = new Rectangle(0, 0, image.getWidth(), image.getHeight());
		Rectangle roi = region.intersection(bounds);
		if ((roi.width == 0) || (roi.height == 0)) {
			return;
		}
		// First, compute the best width x height damaged region
		Point bestSize = getBestImageSize(roi.width, roi.height);
		// Correct the offset if the resulting width is too large
		Point offset = new Point(roi.x, roi.y);
		int dx = roi.x + bestSize.x - bounds.width;
		if (dx > 0) {
			offset.x -= dx;
		}
		// Check which method to use to extract data
		boolean fullSize = (bestSize.x == bounds.width) && (bestSize.y == bounds.height);
		int[] data = null;
		if (fullSize) {
			// Full size area case: we just get the data buffer reference
			data = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
			// And blit it onto the widget area
			SetDIBitsToDevice(gc.handle, 0, 0, bestSize.x, bestSize.y, 0, 0, data,
				bestSize.x, bestSize.y);
		} else {
			// Partial area case: we extract the required sub image
			// We act upon the raster intead of the image (pixels) to preserve the data
			// model and band layout
			java.awt.Rectangle subImage = new java.awt.Rectangle(offset.x, offset.y,
				bestSize.x, bestSize.y);
			data = ((DataBufferInt) image.getData(subImage).getDataBuffer()).getData();
			// We are now ready to blit the pixels, but we must take into account
			// for the new image size and offset
			SetDIBitsToDevice(gc.handle, offset.x, offset.y, bestSize.x, bestSize.y, 0,
				0, data, bestSize.x, bestSize.y);
			// We are now ready to blit the pixels, but we must take into account
			// for the new image size and offset
		}
		// Help the GC do its job
		data = null;
		bestSize = null;
		offset = null;
	}

	/**
	 * Do a bulk bitblt between a byte array and the SWT drawing surface
	 * 
	 * Coordinates are all expressed in the SWT widget coordinates, as the information
	 * usually comes from a paint event on such a surface. It is up to the native code to
	 * understand this coordinate system. <B>The byte array must have a known pixel
	 * layout, fixed for all the images: this is the main weakness of the current code!
	 * </B>
	 * 
	 * @param hdcDest
	 *            A native handle to the target widget, usually the gc.handle attribute
	 * @param xDest
	 *            The x coordinate of the upper-left destination area, in widget
	 *            coordinates
	 * @param yDest
	 *            The y coordinate of the upper-left destination area, in widget
	 *            coordinates
	 * @param width
	 *            The width of the destination area
	 * @param height
	 *            The height of the destination area
	 * @param xSrc
	 *            The x coordinate of the upper-left source area, also in widget
	 *            coordinates
	 * @param ySrc
	 *            The y coordinate of the upper-left source area, also in widget
	 *            coordinates
	 * @param imgWidth
	 *            The width of the image portion in the byte array
	 * @param imgHeight
	 *            The height of the image portion in the byte array
	 * @param data
	 *            The int array that holds the pixel data
	 */
	static private native void SetDIBitsToDevice(int hdcDest, int xDest, int yDest,
		int width, int height, int xSrc, int ySrc, int[] data, int imgWidth, int imgHeight);
}
