#include "org_holongate_j2d_win32_Win32Graphics2DFactory.h"
#include <windows.h>

/*
 * Class:     org_holongate_j2d_win32_Win32Graphics2DFactory
 * Method:    SetDIBitsToDevice
 * Signature: (IIIIIII[III)V
 */
JNIEXPORT void JNICALL Java_org_holongate_j2d_win32_Win32Graphics2DFactory_SetDIBitsToDevice
	(JNIEnv *env, jclass c, jint hdcDest, jint xDest, jint yDest, jint width, jint height, jint xSrc, jint ySrc, jintArray data, jint imgWidth, jint imgHeight) {

	BITMAPINFOHEADER header = {
		(DWORD) sizeof(BITMAPINFOHEADER),
		(LONG) imgWidth,
		(LONG) -imgHeight,
		(WORD) 1,
		(WORD) 32,
		BI_RGB,
		(DWORD) 0,
		(LONG) 0,
		(LONG) 0,
		(DWORD) 0,
		(DWORD) 0
	};
	BITMAPINFO lpbmi = {
		header,
		NULL
	};

	jint* lpvBits = (*env)->GetPrimitiveArrayCritical(env, data, 0);

	// Windows is a mess trust me!
	// Even if the image is marked as 'up to bottom', the source origin is
	// always the lower-left image corner!
	// That's why we translate ySrc -> imgHeight - (ySrc + height)
	// Not doing this will give you strange effects in some area overlapping combinaisons.
	int result =
		SetDIBitsToDevice((HDC)hdcDest,xDest,yDest,width,height,xSrc,imgHeight - (ySrc + height),
			(UINT)0,(UINT)imgHeight,(void *) lpvBits,&lpbmi,DIB_RGB_COLORS);

	// Array is released without writing back data (JNI_ABORT)
	(*env)->ReleasePrimitiveArrayCritical(env, data, lpvBits, JNI_ABORT);
}
