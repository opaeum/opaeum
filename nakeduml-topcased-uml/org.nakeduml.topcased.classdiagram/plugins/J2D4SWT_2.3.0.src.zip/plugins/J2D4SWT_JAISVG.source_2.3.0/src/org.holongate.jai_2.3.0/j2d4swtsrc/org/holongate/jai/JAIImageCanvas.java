/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.jai;

import javax.media.jai.JAI;
import javax.media.jai.RenderedOp;

import org.eclipse.swt.widgets.Composite;
import org.holongate.j2d.J2DCanvas;

/**
 * A very simple canvas that can be initialized with a RenderedOp image.
 * 
 * bug 1206460 (Missing style bit parameter in JAICanvas): All constructors now have a
 * style bit parameter.
 * 
 * 
 * @author Christophe Avare
 * @version $Revision: 1.2.6.1 $
 */
public class JAIImageCanvas extends J2DCanvas {
	private JAIPaintable jaiPaintable;

	/**
	 * Constructor for JAIImageCanvas.
	 * 
	 * @param parent
	 */
	public JAIImageCanvas(Composite parent, int style) {
		super(parent, style, new JAIPaintable());
		jaiPaintable = (JAIPaintable) getPaintable();
	}

	/**
	 * Constructor for JAIImageCanvas.
	 * 
	 * @param parent
	 */
	public JAIImageCanvas(Composite parent, int style, RenderedOp source) {
		super(parent, style, new JAIPaintable(source));
		jaiPaintable = (JAIPaintable) getPaintable();
	}

	/**
	 * Constructor for JAIImageCanvas.
	 * 
	 * @param parent
	 */
	public JAIImageCanvas(Composite parent, int style, String file) {
		super(parent, style, new JAIPaintable(JAI.create("fileload", file)));
		jaiPaintable = (JAIPaintable) getPaintable();
	}

	/**
	 * Returns the jaiPaintable.
	 * 
	 * @return JAIPaintable
	 */
	public JAIPaintable getJAIPaintable() {
		return jaiPaintable;
	}
}
