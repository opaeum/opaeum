/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.jai;

import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;

import javax.media.jai.RenderedOp;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.widgets.Control;
import org.holongate.j2d.IPaintable;

/**
 * This class is an IPaintable that can render RenderedOp images. <br>
 * The paint process simply calls the Graphics2D drawRenderedImage method with an identity
 * transform. I hope that the Java2D internals are sufficiently optimized so that the
 * rendering process uses the clip rectangle of the Graphics2D... For tiled images,
 * iteration over the tiles should gain some speed for very large images.
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1.4.1 $
 */
public class JAIPaintable implements IPaintable {
	private static final AffineTransform IDENTITY = new AffineTransform();
	private RenderedOp source;

	public JAIPaintable() {
		super();
	}

	public JAIPaintable(RenderedOp source) {
		this.source = source;
	}

	/**
	 * Render the source image using the drawRenderedImage() method. <br>
	 * The user to image transform used is the identity as all the transform information
	 * is given by the Graphics2D.
	 */
	public void paint(Control control, Graphics2D g2d) {
		if (source != null) {
			// TODO: next version should check for tiled images
			// and compute which tiles are really needed
			g2d.drawRenderedImage(source, IDENTITY);
		}
	}

	public void redraw(Control control, GC gc) {
	}

	/**
	 * Returns the source.
	 */
	public RenderedOp getSource() {
		return source;
	}

	/**
	 * Sets the source.
	 * 
	 * @param source
	 *            The source to set
	 */
	public void setSource(RenderedOp source) {
		this.source = source;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.holongate.eclipse.j2d.IPaintable#getBounds(org.eclipse.swt.widgets.Control)
	 */
	public Rectangle2D getBounds(Control control) {
		if (source == null) {
			return new Rectangle2D.Double(0, 0, 1, 1);
		}
		return source.getBounds();
	}
}
