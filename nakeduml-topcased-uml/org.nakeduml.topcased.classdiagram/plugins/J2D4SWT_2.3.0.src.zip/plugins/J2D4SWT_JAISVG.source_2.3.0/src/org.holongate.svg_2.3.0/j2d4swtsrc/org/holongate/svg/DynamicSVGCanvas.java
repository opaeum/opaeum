/*
 * Created on 7 nov. 03
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package org.holongate.svg;

import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.util.List;

import org.apache.batik.bridge.BridgeContext;
import org.apache.batik.bridge.DocumentLoader;
import org.apache.batik.bridge.DynamicGVTBuilder;
import org.apache.batik.bridge.UpdateManager;
import org.apache.batik.css.engine.CSSEngine;
import org.apache.batik.css.engine.CSSEngineEvent;
import org.apache.batik.css.engine.CSSEngineListener;
import org.apache.batik.dom.svg.SVGOMDocument;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.widgets.Composite;
import org.holongate.j2d.IPaintableManager;
import org.holongate.j2d.J2DUtilities;
import org.w3c.dom.events.Event;
import org.w3c.dom.events.EventListener;
import org.w3c.dom.events.EventTarget;
import org.w3c.dom.svg.SVGDocument;

/**
 * @author chris
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class DynamicSVGCanvas extends SimpleSVGCanvas {
	protected UpdateManager updateMgr;
	protected EventListener domListener;
	protected CSSEngineListener cssListener;
	protected boolean initialized = false;
	protected CSSEngine cssEngine;

	/**
	 * @param parent
	 * @param uri
	 */
	public DynamicSVGCanvas(Composite parent, String uri) {
		super(parent, uri);
	}

	/**
	 * @param parent
	 * @param style
	 * @param manager
	 * @param uri
	 */
	public DynamicSVGCanvas(
		Composite parent,
		int style,
		IPaintableManager manager,
		String uri) {
		super(parent, style, manager, uri);
	}

	/**
	 * @param parent
	 * @param style
	 * @param uri
	 */
	public DynamicSVGCanvas(Composite parent, int style, String uri) {
		super(parent, style, uri);
	}

	/* (non-Javadoc)
	 * @see org.holongate.svg.SimpleSVGCanvas#loadDocument()
	 */
	protected void loadDocument() {
		builder = new DynamicGVTBuilder();
		userAgent = new SimpleSWTUserAgent(this);
		loader = new DocumentLoader(userAgent);
		SimpleSWTUserAgent.XercesWorkaround();
		try {
			svgDocument = (SVGDocument) loader.loadDocument(uri);
			bridgeContext = new BridgeContext(userAgent, loader);
			bridgeContext.setDynamicState(BridgeContext.DYNAMIC);
			gvtRoot = builder.build(bridgeContext, svgDocument);
			getSVGPaintable().setTree(gvtRoot);
			updateMgr = new UpdateManager(bridgeContext, gvtRoot, svgDocument);
			// Catch all the dom events
			EventTarget evtTarget = (EventTarget) svgDocument;
			domListener = new EventListener() {
				public void handleEvent(Event arg0) {
					updateDirtyAreas();
				}
			};
			evtTarget.addEventListener("DOMAttrModified", domListener, false);
			evtTarget.addEventListener("DOMNodeInserted", domListener, false);
			evtTarget.addEventListener("DOMNodeRemoved", domListener, false);
			evtTarget.addEventListener(
				"DOMCharacterDataModified",
				domListener,
				false);

			// And all the CSS property changes
			cssEngine = ((SVGOMDocument) svgDocument).getCSSEngine();
			cssListener = new CSSEngineListener() {
				public void propertiesChanged(CSSEngineEvent evt) {
					updateDirtyAreas();
				}
			};
			cssEngine.addCSSEngineListener(cssListener);
		} catch (Exception e) {
			e.printStackTrace();
			userAgent.displayError(e);
		}
	}

	/* (non-Javadoc)
	 * @see org.holongate.svg.SimpleSVGCanvas#cleanup()
	 */
	public void cleanup() {
		updateMgr.interrupt();
		//CSSEngine cssEngine = ((SVGOMDocument) svgDocument).getCSSEngine();
		cssEngine.removeCSSEngineListener(cssListener);
		EventTarget evtTarget = (EventTarget) svgDocument;
		evtTarget.removeEventListener("DOMAttrModified", domListener, false);
		evtTarget.removeEventListener("DOMNodeInserted", domListener, false);
		evtTarget.removeEventListener("DOMNodeRemoved", domListener, false);
		evtTarget.removeEventListener(
			"DOMCharacterDataModified",
			domListener,
			false);
		domListener = null;
		cssListener = null;
		updateMgr = null;
		super.cleanup();
	}

	private void updateDirtyAreas() {
		if (isDisposed()) {
			return;
		}
		List l = updateMgr.getUpdateTracker().getDirtyAreas();
		if (l == null) {
			return;
		}
		updateMgr.getUpdateTracker().clear();
		//System.err.println("handleEvent(): " + l.size());
		final Rectangle dirty = new Rectangle();
		AffineTransform t = getPaintableManager().getCanvasTransform();
		for (int i = 0; i < l.size(); i++) {
			Rectangle2D ts =
				t
					.createTransformedShape(((Shape) l.get(i)).getBounds2D())
					.getBounds2D();
			dirty.add(ts);
			if (isDisposed()) {
				return;
			}
			paint(J2DUtilities.toRectangle(ts));
		}
		if (isDisposed()) {
			return;
		}
		getDisplay().asyncExec(new Runnable() {
			public void run() {
				if (!DynamicSVGCanvas.this.isDisposed()) {
					paint(
						dirty.x,
						dirty.y,
						dirty.width,
						dirty.height,
						true,
						PAINT_DAMAGED);
				}
			}
		});
	}
	/* (non-Javadoc)
	 * @see org.holongate.j2d.IPaintableCanvas#applyPaintEvent(org.eclipse.swt.events.PaintEvent, int)
	 */
	public void applyPaintEvent(PaintEvent event, int mode) {
		if (!initialized) {
			updateMgr.manageUpdates(getSVGPaintable());
			try {
				updateMgr.dispatchSVGLoadEvent();
				initialized = true;
			} catch (InterruptedException e) {
			}
		}
		super.applyPaintEvent(event, mode);
	}

}