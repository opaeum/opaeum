/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.svg;

import java.awt.Graphics2D;
import java.lang.ref.WeakReference;

import org.apache.batik.bridge.BridgeContext;
import org.apache.batik.bridge.DocumentLoader;
import org.apache.batik.bridge.GVTBuilder;
import org.apache.batik.bridge.UserAgent;
import org.apache.batik.ext.awt.RenderingHintsKeyExt;
import org.apache.batik.gvt.GraphicsNode;
import org.eclipse.swt.widgets.Composite;
import org.holongate.j2d.IPaintableManager;
import org.holongate.j2d.J2DCanvas;
import org.w3c.dom.svg.SVGDocument;

/**
 * A simpleSVGCanvas is a 'load and forget' SVG document viewer
 * without dynamic or interactive capabilities.
 * It's the simplest J2DCanavs able to display static documents
 * which may be used to quickly display SVG files like in thumbnail or
 * preview windows.
 * No asynchronous loading mechanism is available.
 * 
 * @author Christophe Avare
 * @version $Revision: 1.2 $
 */
public class SimpleSVGCanvas extends J2DCanvas {
	protected String uri;
	protected GVTBuilder builder;
	protected UserAgent userAgent;
	protected DocumentLoader loader;
	protected SVGDocument svgDocument;
	protected BridgeContext bridgeContext;
	protected GraphicsNode gvtRoot;

	/**
	 * Constructs a new canvas given the SWT parent and the document
	 * uri.
	 * The document is immediately loaded.
	 * The new canvas will have the default style a DefaultPaintableManager().
	 * 
	 * @param parent The SWT parent composite
	 * @param uri The document uri
	 */
	public SimpleSVGCanvas(Composite parent, String uri) {
		super(parent, new SVGPaintable());
		this.uri = uri;
		getSVGPaintable().setCanvas(this);
		loadDocument();
	}

	/**
	 * Constructs a new canvas given the SWT parent, a syle,
	 * a paintable manager and the document uri.
	 * The document is immediately loaded.
	 * 
	 * @param parent The SWT parent composite
	 * @param style The canavs style to apply
	 * @param manager The IPaintableManager to use
	 * @param uri The document uri
	 */
	public SimpleSVGCanvas(
		Composite parent,
		int style,
		IPaintableManager manager,
		String uri) {
		super(parent, style, new SVGPaintable(), manager);
		this.uri = uri;
		getSVGPaintable().setCanvas(this);
		loadDocument();
	}

	/**
	 * Constructs a new canvas given the SWT parent, a syle,
	 * a default paintable manager and the document uri.
	 * The document is immediately loaded.
	 * 
	 * @param parent The SWT parent composite
	 * @param style The canavs style to apply
	 * @param uri The document uri
	 */
	public SimpleSVGCanvas(Composite parent, int style, String uri) {
		super(parent, style, new SVGPaintable());
		this.uri = uri;
		getSVGPaintable().setCanvas(this);
		loadDocument();
	}

	/**
	 * Returns the SVGPaintable internally created by this canvas.
	 * 
	 * @return The SVGPaintable that will be used for renderings
	 */
	public SVGPaintable getSVGPaintable() {
		return (SVGPaintable) getPaintable();
	}

	/**
	 * To be correctly used by the Batik's GVT rendering machinery,
	 * the Graphics2D must have the RenderingHintsKeyExt.KEY_BUFFERED_IMAGE
	 * rendering hint set to the buffered image this Graphics2D was created for.
	 */
	public void initGraphics(Graphics2D g2d) {
		super.initGraphics(g2d);
		g2d.setRenderingHint(
			RenderingHintsKeyExt.KEY_BUFFERED_IMAGE,
			new WeakReference(getGraphics2DFactory().getOffscreenImage()));
	}

	/**
	 * Loads an SVG document.
	 * The document is parsed, a bridge context attached to it and the GVT
	 * Tree generated.
	 * A dispose listener is attached to the canvas that will
	 * call forgetDocument().
	 *
	 */
	protected void loadDocument() {
		builder = new GVTBuilder();
		userAgent = new SimpleSWTUserAgent(this);
		loader = new DocumentLoader(userAgent);
		SimpleSWTUserAgent.XercesWorkaround();
		try {
			svgDocument = (SVGDocument) loader.loadDocument(uri);
			bridgeContext = new BridgeContext(userAgent, loader);
			bridgeContext.setDynamicState(BridgeContext.STATIC);
			gvtRoot = builder.build(bridgeContext, svgDocument);
			getSVGPaintable().setTree(gvtRoot);
		} catch (Exception e) {
			userAgent.displayError(e);
		}
	}

	/**
	 * Forgets the loaded document by unbinding the bridge context, disposing
	 * the document loader and GVT builder.
	 * Memory internally used by BAtik must be released after a call to this
	 * method.
	 */
	public void cleanup() {
		if (bridgeContext != null) {
			bridgeContext.dispose();
		}
		bridgeContext = null;
		if (loader != null) {
			loader.dispose();
		}
		loader = null;
		builder = null;
		svgDocument = null;
		userAgent = null;
		super.cleanup();
	}
}
