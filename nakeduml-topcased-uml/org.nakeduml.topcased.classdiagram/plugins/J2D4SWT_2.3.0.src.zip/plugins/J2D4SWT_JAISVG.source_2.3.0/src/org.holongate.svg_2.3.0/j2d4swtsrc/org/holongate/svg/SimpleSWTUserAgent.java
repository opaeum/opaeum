/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Dave Carlson - initial API and implementation               *
 *****************************************************************************/
package org.holongate.svg;

import java.net.URLDecoder;
import java.util.LinkedList;
import java.util.List;

import org.apache.batik.bridge.UserAgentAdapter;
import org.apache.batik.gvt.event.EventDispatcher;
import org.apache.batik.swing.svg.LinkActivationEvent;
import org.apache.batik.swing.svg.LinkActivationListener;
import org.apache.batik.swing.svg.SVGUserAgent;
import org.apache.batik.util.XMLResourceDescriptor;
import org.eclipse.core.runtime.Platform;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.holongate.batik.gvt.event.SWTEventDispatcher;
import org.holongate.j2d.IPaintableCanvas;
import org.w3c.dom.svg.SVGAElement;

/**
 * A UserAgent implemented using the SWT capabilities only.
 * 
 * @author Dave Carlson
 * @version $Revision: 1.1 $
 */
public class SimpleSWTUserAgent
	extends UserAgentAdapter
	implements SVGUserAgent {
	public static final Cursor CURSOR_ARROW =
		new Cursor(Display.getCurrent(), SWT.CURSOR_ARROW);
	public static final Cursor CURSOR_WAIT =
		new Cursor(Display.getCurrent(), SWT.CURSOR_WAIT);
	public static final Cursor CURSOR_HAND =
		new Cursor(Display.getCurrent(), SWT.CURSOR_HAND);

	protected IPaintableCanvas gvtCanvas;
	protected SWTEventDispatcher dispatcher;

	/**
	 * The link activation listeners.
	 */
	protected List linkActivationListeners = new LinkedList();

	/*
	 * There must be a better way...
	 * These are temporary variables used to pass results from inner
	 * classes in the display methods below.
	 */
	protected boolean booleanResult;
	protected String stringResult;

	/**
	 * Constructor for DefaultUserAgent.
	 */
	public SimpleSWTUserAgent(IPaintableCanvas canvas) {
		super();
		gvtCanvas = canvas;
	}

	/**
	 * Returns the canvas.
	 * @return GVTComponent
	 */
	public IPaintableCanvas getCanvas() {
		return gvtCanvas;
	}

	/**
	 * Adds a LinkActivationListener to this component.
	 */
	public void addLinkActivationListener(LinkActivationListener l) {
		linkActivationListeners.add(l);
	}

	/**
	 * Removes a LinkActivationListener from this component.
	 */
	public void removeLinkActivationListener(LinkActivationListener l) {
		linkActivationListeners.remove(l);
	}

	/* ******
	 * 
	 * Implementation of UserAgent
	 * 
	 * ******/

	/**
	 * Returns the <code>EventDispatcher</code> used by the
	 * <code>UserAgent</code> to dispatch events on GVT.
	 */
	public EventDispatcher getEventDispatcher() {
		if (dispatcher == null) {
			dispatcher =
				new SWTEventDispatcher((SVGPaintable) gvtCanvas.getPaintable());
		}
		return dispatcher;
	}

	/**
	 * Returns the class name of the XML parser.
	 */
	public String getXMLParserClassName() {
		return XMLResourceDescriptor.getXMLParserClassName();
	}

	/**
	 * Informs the user agent to change the cursor.
	 * @param cursor the new cursor
	 */
	public void setSVGCursor(java.awt.Cursor cursor) {
		Shell shell = gvtCanvas.getControl().getShell();
		// convert AWT curor to SWT cursor
		if (cursor.getType() == java.awt.Cursor.DEFAULT_CURSOR)
			shell.setCursor(CURSOR_ARROW);
		else if (cursor.getType() == java.awt.Cursor.HAND_CURSOR)
			shell.setCursor(CURSOR_HAND);
		else if (cursor.getType() == java.awt.Cursor.WAIT_CURSOR)
			shell.setCursor(CURSOR_WAIT);
	}

	/**
	 * Opens a link.
	 * @param elt The activated link element.
	 */
	public void openLink(SVGAElement elt) {
	}

	/**
	 * Fires a LinkActivatedEvent.
	 */
	protected void fireLinkActivatedEvent(SVGAElement elt, String href) {
		Object[] ll = linkActivationListeners.toArray();

		if (ll.length > 0) {
			LinkActivationEvent ev;
			ev = new LinkActivationEvent(gvtCanvas, elt, href);

			for (int i = 0; i < ll.length; i++) {
				LinkActivationListener l = (LinkActivationListener) ll[i];
				l.linkActivated(ev);
			}
		}
	}

	/**
	 * Opens a link.
	 * Implements the SVGUserAgent interface.
	 * 
	 * @param uri The document URI.
	 * @param newc Whether the link should be activated in a new component.
	 */
	public void openLink(String uri, boolean newc) {
		//TODO: how do I cause caller to open a new view/editor?
	}

	/**
	 * Displays an error resulting from the specified Exception.
	 */
	public void displayError(final Exception ex) {
		ex.printStackTrace();
		MessageBox error =
			new MessageBox(
				gvtCanvas.getControl().getShell(),
				SWT.ICON_ERROR | SWT.OK);
		error.setText("SVG Error");
		error.setMessage(ex.toString());
		error.open();
	}

	/**
	 * Displays a message in the User Agent interface.
	 */
	public void displayMessage(final String message) {
		System.out.println(
			"SimpleSWTUserAgent message:\n" + URLDecoder.decode(message));
	}

	/**
	 * Shows an alert dialog box.
	 */
	public void showAlert(final String message) {
		MessageBox error =
			new MessageBox(
				gvtCanvas.getControl().getShell(),
				SWT.ICON_WARNING | SWT.OK);
		error.setText("SVG Warning");
		error.setMessage(message);
		error.open();
	}

	/**
	 * Shows a prompt dialog box.
	 */
	public String showPrompt(final String message) {
		return showPrompt(message, null);
	}

	/**
	 * Shows a prompt dialog box.
	 */
	public String showPrompt(final String message, final String defaultValue) {
		PromptDialog input =
			new PromptDialog(gvtCanvas.getControl().getShell());
		input.setText("SVG Prompt");
		input.setMessage(message);
		input.setValue(defaultValue);
		input.open();
		return input.getValue();
	}

	/**
	 * Shows a confirm dialog box.
	 */
	public boolean showConfirm(final String message) {
		MessageBox confirm =
			new MessageBox(
				gvtCanvas.getControl().getShell(),
				SWT.ICON_QUESTION | SWT.YES | SWT.NO);
		confirm.setText("SVG Confirmation");
		confirm.setMessage(message);
		return (confirm.open() == SWT.YES);
	}

	static void XercesWorkaround() {
		try {
			Thread.currentThread().setContextClassLoader(
				Platform
					.getPluginRegistry()
					.getPluginDescriptor("org.apache.batik")
					.getPluginClassLoader());
		}
		catch (Throwable t) {}
		finally {}
	}
}
