/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.svg;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.Collection;
import java.util.List;

import org.apache.batik.ext.awt.geom.RectListManager;
import org.apache.batik.gvt.GraphicsNode;
import org.apache.batik.gvt.renderer.ImageRenderer;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Control;
import org.holongate.j2d.IPaintable;
import org.holongate.j2d.IPaintableCanvas;

/**
 * The SVGPaintable is both an IPaintable (for J2D4SWT compatibility) and a Batik
 * ImageRenderer so that any SVG rendering can be performed on it.
 * 
 * @author Christophe Avare
 * @version $Revision: 1.3.4.1 $
 */
public class SVGPaintable implements IPaintable, ImageRenderer {
	private GraphicsNode gvtRoot;
	private IPaintableCanvas canvas;

	/**
	 * Default constructor. To be useful, the new SVGPaintable must be bound to an
	 * IPaintableCanvas by calling setCanvas().
	 */
	public SVGPaintable() {
		super();
	}

	/**
	 * Painting an SVGPaintable is just calling paint() on the GVT root node with the
	 * provided Graphics2D argument. The Composite is forced to be AlphaComposite.Clear
	 * because the background MUST be erased before drawing.
	 */
	public void paint(Control control, Graphics2D g2d) {
		if (gvtRoot != null) {
			g2d.setComposite(AlphaComposite.Clear);
			gvtRoot.paint(g2d);
		}
	}

	public void redraw(Control control, GC gc) {
	}

	/**
	 * Returns the root node bounds, or Rectangle(0,0,1,1) if no node has been set.
	 * 
	 * @see org.holongate.j2d.IPaintable#getBounds(org.eclipse.swt.widgets.Control)
	 */
	public Rectangle2D getBounds(Control control) {
		if (gvtRoot != null) {
			return gvtRoot.getBounds();
		}
		return new Rectangle2D.Double(0, 0, 1, 1);
	}

	/**
	 * Returns the current IPaintableCanvas bound to this paintable.
	 * 
	 * @return The current IPintableCanvas
	 */
	public IPaintableCanvas getCanvas() {
		return canvas;
	}

	/**
	 * Sets the IPaintableCanvas this paintable is bound. This ionformation is necessary
	 * to get access to the actual coordinate transformation and other information.
	 * 
	 * @param canvas
	 *            An IPaintableCanvas
	 */
	public void setCanvas(IPaintableCanvas canvas) {
		this.canvas = canvas;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.batik.gvt.renderer.Renderer#dispose()
	 */
	public void dispose() {
		System.err.println("dispose()");
	}

	/**
	 * The paintable transform to apply to the SVG document is the one sets on the
	 * paintable canvas itself.
	 * 
	 * @see org.apache.batik.gvt.renderer.Renderer#getTransform()
	 */
	public AffineTransform getTransform() {
		return canvas.getPaintableManager().getCanvasTransform();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.batik.gvt.renderer.Renderer#getTree()
	 */
	public GraphicsNode getTree() {
		return gvtRoot;
	}

	/**
	 * This ImageRenderer is by design double buffered. This information is needed by the
	 * Batik rendering engine to generate correct flush / repaint calls.
	 * 
	 * @see org.apache.batik.gvt.renderer.Renderer#isDoubleBuffered()
	 */
	public boolean isDoubleBuffered() {
		return false;
	}

	/**
	 * Noop method
	 * 
	 * @param isDoubleBuffered
	 *            Ignored
	 * 
	 * @see org.apache.batik.gvt.renderer.Renderer#setDoubleBuffered(boolean)
	 */
	public void setDoubleBuffered(boolean isDoubleBuffered) {
		//System.err.println("setDoubleBuffered(" + isDoubleBuffered + ")");
		// No effect
	}

	/**
	 * Noop method
	 * 
	 * @param usr2dev
	 *            Ignored
	 * 
	 * @see org.apache.batik.gvt.renderer.Renderer#setTransform(java.awt.geom.AffineTransform)
	 */
	public void setTransform(AffineTransform usr2dev) {
		//System.err.println("setTransform(AffineTransform usr2dev)");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.batik.gvt.renderer.Renderer#setTree(org.apache.batik.gvt.GraphicsNode)
	 */
	public void setTree(GraphicsNode gvtRoot) {
		this.gvtRoot = gvtRoot;
		canvas.getGraphics2DFactory().setSize(new Point(1, 1));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.batik.gvt.renderer.ImageRenderer#clearOffScreen()
	 */
	public void clearOffScreen() {
		//System.err.println("clearOffScreen()");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.batik.gvt.renderer.ImageRenderer#flush()
	 */
	public void flush() {
		//System.err.println("flush()");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.batik.gvt.renderer.ImageRenderer#flush(java.util.List)
	 */
	public void flush(List areas) {
		//System.err.println("flush(List): " + areas);
		/*
		 * synchronized (canvas) { if (canvas.getControl().isDisposed()) { return; }
		 * Iterator it = areas.listIterator(); Rectangle area = new Rectangle(); while
		 * (it.hasNext()) { area.add(((Shape) it.next()).getBounds2D()); } final Rectangle
		 * damaged = canvas .getPaintableManager() .getCanvasTransform()
		 * .createTransformedShape(area) .getBounds();
		 * canvas.getControl().getDisplay().asyncExec(new Runnable() { public void run() { //
		 * Widget may have been disposed while queuing this event if
		 * (canvas.getControl().isDisposed()) { return; } canvas.paint( damaged.x - 1,
		 * damaged.y - 1, damaged.width + 2, damaged.height + 2, true,
		 * IPaintableCanvas.PAINT_DAMAGED); } }); }
		 */
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.batik.gvt.renderer.ImageRenderer#flush(java.awt.Rectangle)
	 */
	public void flush(Rectangle r) {
		//System.err.println("flush(Rectangle)");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.batik.gvt.renderer.ImageRenderer#getOffScreen()
	 */
	public BufferedImage getOffScreen() {
		return canvas.getGraphics2DFactory().getOffscreenImage();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.batik.gvt.renderer.ImageRenderer#updateOffScreen(int, int)
	 */
	public void updateOffScreen(int width, int height) {
		//System.err.println("updateOffScreen(int width, int height)");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.batik.gvt.renderer.ImageRenderer#flush(java.util.Collection)
	 */
	public void flush(Collection arg0) {
		//System.err.println("flush(Collection)");
	}

	/**
	 * Repaints the areas found in a list of rectangles. The global bounding box is
	 * repainted in one operation instead of each small rectangle because the bit blitting
	 * operation is much efficient on larger areas compared to call overhead. A Runnnable
	 * is created on the fly so that the rendering is done inside the SWT thread. Because
	 * of this limitation, a delay between the request and the rendering update is not
	 * constsant and predictible (but requests are queued so they will all be honored!).
	 * Dynamic SVG documents and animation quality will highly depend on the CPU power.
	 * 
	 * @see org.apache.batik.gvt.renderer.Renderer#repaint(org.apache.batik.ext.awt.geom.RectListManager)
	 */
	public void repaint(RectListManager rlmgr) {
		//System.err.println("repaint(RectListManager): "+rlmgr.size());
		//		synchronized (canvas) {
		//			if (canvas.getControl().isDisposed()) {
		//				return;
		//			}
		//			final Rectangle damaged = rlmgr.getBounds();
		//			canvas.getControl().getDisplay().asyncExec(new Runnable() {
		//				public void run() {
		//					// Widget may have been disposed while queuing this event
		//					if (canvas.getControl().isDisposed()) {
		//						return;
		//					}
		//					// Take antialiasing into account
		//					org.eclipse.swt.graphics.Rectangle d =
		//						new org.eclipse.swt.graphics.Rectangle(
		//							damaged.x - 1,
		//							damaged.y - 1,
		//							damaged.width + 2,
		//							damaged.height + 2);
		//					((AbstractJ2DCanvas) canvas).paint(d);
		//					GC gc = new GC(canvas.getControl());
		//					gc.setClipping(d);
		//					canvas.getGraphics2DFactory().update(d, gc);
		//					gc.dispose();
		//				}
		//			});
		//		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.batik.gvt.renderer.Renderer#repaint(java.awt.Shape)
	 */
	public void repaint(Shape area) {
		//System.err.println("repaint(Shape)");
	}

}
