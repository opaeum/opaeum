/*****************************************************************************
 * Copyright (C) The Apache Software Foundation. All rights reserved.        *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the Apache Software License *
 * version 1.1, a copy of which has been included with this distribution in  *
 * the LICENSE file.                                                         *
 *****************************************************************************/
/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Dave Carlson - initial API and implementation               *
 *               Christophe Avare - full mouse button / modifiers mapping,   *
 *                                  coordinate conversion screen -> user     *
 *****************************************************************************/
package org.holongate.batik.gvt.event;

/*
import java.awt.Point;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
*/

import java.awt.event.InputEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.Point2D;
import java.lang.reflect.Array;
import java.util.EventListener;
import java.util.EventObject;

import javax.swing.event.EventListenerList;

import org.apache.batik.gvt.GraphicsNode;
import org.apache.batik.gvt.TextNode;
import org.apache.batik.gvt.event.EventDispatcher;
import org.apache.batik.gvt.event.GraphicsNodeInputEvent;
import org.apache.batik.gvt.event.GraphicsNodeKeyEvent;
import org.apache.batik.gvt.event.GraphicsNodeKeyListener;
import org.apache.batik.gvt.event.GraphicsNodeMouseEvent;
import org.apache.batik.gvt.event.GraphicsNodeMouseListener;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.MouseMoveListener;
import org.eclipse.swt.events.MouseTrackListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Control;
import org.holongate.svg.SVGPaintable;

/**
 * An EventDispatcher implementation based on AWT events.
 *
 * <p>Mouse events are dispatched to their "containing" node (the
 * GraphicsNode corresponding to the mouse event coordinate). Searches
 * for containment are performed from the EventDispatcher's "root"
 * node.</p>
 *
 * @author <a href="bill.haneman@ireland.sun.com>Bill Haneman</a>
 * @author <a href="cjolif@ilog.fr>Christophe Jolif</a>
 * @author <a href="tkormann@ilog.fr>Thierry Kormann</a>
 * @version AFS: AWTEventDispatcher.java,v 1.16 2003/07/10 12:01:18 deweese Exp
 *
 * @version $Id: SWTEventDispatcher.java,v 1.2 2004/05/01 20:31:40 c-avare Exp $
 */
public class SWTEventDispatcher
	implements
		EventDispatcher,
		MouseListener,
		MouseMoveListener,
		MouseTrackListener,
		KeyListener {

	/**
	 * The SVGPaintable this dispatcher is bound to
	 */
	private SVGPaintable svgPaintable;

	/**
	 * The global listener list.
	 */
	protected EventListenerList glisteners;

	/**
	 * The lastest node which has been targeted by an event.
	 */
	protected GraphicsNode lastHit;

	/**
	 * A dummy graphics node to dispacth "deselect" mouse events to. ie.
	 * when the mouse is clicked outside any nodes.
	 */
	protected GraphicsNode dummyNode = new TextNode();

	/**
	 * The current GraphicsNode targeted by an key events.
	 */
	protected GraphicsNode currentKeyEventTarget;

	//    private int nodeIncrementEventID = SWT.KeyDown;
	//    private int nodeIncrementEventCode = SWT.TRAVERSE_TAB_NEXT;
	//    private int nodeIncrementEventModifiers = 0;
	//    private int nodeDecrementEventID = SWT.KeyDown;
	//    private int nodeDecrementEventCode = SWT.TRAVERSE_TAB_NEXT;
	//    private int nodeDecrementEventModifiers = SWT.SHIFT;

	/**
	 * Constructs a new event dispatcher.
	 */
	public SWTEventDispatcher(SVGPaintable svgPaintable) {
		this.svgPaintable = svgPaintable;
		Control c = svgPaintable.getCanvas().getControl();
		c.addMouseListener(this);
		c.addMouseMoveListener(this);
		c.addMouseTrackListener(this);
		c.addKeyListener(this);
	}

	/**
	 * Sets the root node for MouseEvent dispatch containment searches
	 * and field selections.
	 * @param root the root node
	 */
	public void setRootNode(GraphicsNode root) {
		//No op: root node is taken from the paintable itself
	}

	/**
	 * Returns the root node for MouseEvent dispatch containment
	 * searches and field selections.
	 */
	public GraphicsNode getRootNode() {
		return svgPaintable.getTree();
	}

	/**
	 * Sets the base transform applied to MouseEvent coordinates prior
	 * to dispatch.
	 * @param t the affine transform
	 */
	public void setBaseTransform(AffineTransform t) {
		throw new IllegalAccessError("SWTEventDispatcher::setBaseTransform() method must nor be call by clients");
	}

	/**
	 * Returns the base transform applied to MouseEvent coordinates prior
	 * to dispatch.
	 */
	public AffineTransform getBaseTransform() {
		try {
			return svgPaintable
				.getCanvas()
				.getPaintableManager()
				.getCanvasTransform()
				.createInverse();
		} catch (NoninvertibleTransformException e) {
			e.printStackTrace();
		}
		return svgPaintable
			.getCanvas()
			.getPaintableManager()
			.getCanvasTransform();
	}

	//
	// SWT listeners wrapper
	//

	/**
	 * Dispatches the specified SWT mouse event down to the GVT tree.
	 * The mouse event is mutated to a GraphicsNodeMouseEvent.
	 * @param evt the mouse event to propagate
	 */
	public void mouseDown(MouseEvent evt) {
		dispatchMouseEvent(evt, GraphicsNodeMouseEvent.MOUSE_PRESSED);
	}

	/**
	 * Dispatches the specified SWT mouse event down to the GVT tree.
	 * The mouse event is mutated to a GraphicsNodeMouseEvent.
	 * @param evt the mouse event to propagate
	 */
	public void mouseUp(MouseEvent evt) {
		dispatchMouseEvent(evt, GraphicsNodeMouseEvent.MOUSE_RELEASED);
		dispatchMouseEvent(evt, GraphicsNodeMouseEvent.MOUSE_CLICKED);
	}

	/**
	 * Dispatches the specified SWT mouse event down to the GVT tree.
	 * The mouse event is mutated to a GraphicsNodeMouseEvent.
	 * @param evt the mouse event to propagate
	 */
	public void mouseDoubleClick(MouseEvent evt) {
		// Double click work around: click count is passed into the
		// event.data field
		evt.data = new Integer(2);
		dispatchMouseEvent(evt, GraphicsNodeMouseEvent.MOUSE_CLICKED);
	}

	/**
	 * Dispatches the specified SWT mouse event down to the GVT tree.
	 * The mouse event is mutated to a GraphicsNodeMouseEvent.
	 * @param evt the mouse event to propagate
	 */
	public void mouseEnter(MouseEvent evt) {
		dispatchMouseEvent(evt, GraphicsNodeMouseEvent.MOUSE_ENTERED);
	}

	/**
	 * Dispatches the specified SWT mouse event down to the GVT tree.
	 * The mouse event is mutated to a GraphicsNodeMouseEvent.
	 * @param evt the mouse event to propagate
	 */
	public void mouseExit(MouseEvent evt) {
		dispatchMouseEvent(evt, GraphicsNodeMouseEvent.MOUSE_EXITED);
	}

	/**
	 * Dispatches the specified SWT mouse event down to the GVT tree.
	 * The mouse event is mutated to a GraphicsNodeMouseEvent.
	 * @param evt the mouse event to propagate
	 */
	public void mouseHover(MouseEvent evt) {
		// not dispatched
	}

	/**
	 * Dispatches the specified SWT mouse event down to the GVT tree.
	 * The mouse event is mutated to a GraphicsNodeMouseEvent.
	 * @param evt the mouse event to propagate
	 */
	public void mouseMove(MouseEvent evt) {
		dispatchMouseEvent(evt, GraphicsNodeMouseEvent.MOUSE_MOVED);
	}

	/**
	 * Dispatches the specified SWT mouse event down to the GVT tree.
	 * The mouse event is mutated to a GraphicsNodeMouseEvent.
	 * @param evt the mouse event to propagate
	 */
	public void mouseDragged(MouseEvent evt) {
		dispatchMouseEvent(evt, GraphicsNodeMouseEvent.MOUSE_MOVED);
	}

	/**
	 * Dispatches the specified SWT key event down to the GVT tree.
	 * The mouse event is mutated to a GraphicsNodeKeyEvent.
	 * @param evt the key event to propagate
	 */
	public void keyPressed(KeyEvent evt) {
		dispatchKeyEvent(evt, GraphicsNodeKeyEvent.KEY_PRESSED);
	}

	/**
	 * Dispatches the specified SWT key event down to the GVT tree.
	 * The mouse event is mutated to a GraphicsNodeKeyEvent.
	 * @param evt the key event to propagate
	 */
	public void keyReleased(KeyEvent evt) {
		dispatchKeyEvent(evt, GraphicsNodeKeyEvent.KEY_RELEASED);
		dispatchKeyEvent(evt, GraphicsNodeKeyEvent.KEY_TYPED);
	}

	//
	// Global GVT listeners support
	//

	/**
	 * Adds the specified 'global' GraphicsNodeMouseListener which is
	 * notified of all MouseEvents dispatched.
	 * @param l the listener to add
	 */
	public void addGraphicsNodeMouseListener(GraphicsNodeMouseListener l) {
		if (glisteners == null) {
			glisteners = new EventListenerList();
		}
		glisteners.add(GraphicsNodeMouseListener.class, l);
	}

	/**
	 * Removes the specified 'global' GraphicsNodeMouseListener which is
	 * notified of all MouseEvents dispatched.
	 * @param l the listener to remove
	 */
	public void removeGraphicsNodeMouseListener(GraphicsNodeMouseListener l) {
		if (glisteners != null) {
			glisteners.remove(GraphicsNodeMouseListener.class, l);
		}
	}

	/**
	 * Adds the specified 'global' GraphicsNodeKeyListener which is
	 * notified of all KeyEvents dispatched.
	 * @param l the listener to add
	 */
	public void addGraphicsNodeKeyListener(GraphicsNodeKeyListener l) {
		if (glisteners == null) {
			glisteners = new EventListenerList();
		}
		glisteners.add(GraphicsNodeKeyListener.class, l);
	}

	/**
	 * Removes the specified 'global' GraphicsNodeKeyListener which is
	 * notified of all KeyEvents dispatched.
	 * @param l the listener to remove
	 */
	public void removeGraphicsNodeKeyListener(GraphicsNodeKeyListener l) {
		if (glisteners != null) {
			glisteners.remove(GraphicsNodeKeyListener.class, l);
		}
	}

	/**
	 * Returns an array of listeners that were added to this event
	 * dispatcher and of the specified type.
	 * @param listenerType the type of the listeners to return
	 */
	public EventListener[] getListeners(Class listenerType) {
		Object array =
			Array.newInstance(
				listenerType,
				glisteners.getListenerCount(listenerType));
		Object[] pairElements = glisteners.getListenerList();
		for (int i = 0, j = 0; i < pairElements.length - 1; i += 2) {
			if (pairElements[i].equals(listenerType)) {
				Array.set(array, j, pairElements[i + 1]);
				++j;
			}
		}
		return (EventListener[]) array;
	}

	//
	// Event dispatch implementation
	//

	/**
	 * This is required by the EventDispatcher interface, but is
	 * not used for SWT handling of typed events.
	 */
	public void dispatchEvent(EventObject evt) {
		throw new UnsupportedOperationException("dispatchEvent(EventObject) is not supported.");
		/*
		if (root == null)
		    return;
		if (evt instanceof MouseEvent) {
		    dispatchMouseEvent((MouseEvent) evt);
		} else if (evt instanceof KeyEvent) {
		    InputEvent e = (InputEvent)evt;
		    if (isNodeIncrementEvent(e)) {
		        incrementKeyTarget();
		    } else if (isNodeDecrementEvent(e)) {
		        decrementKeyTarget();
		    } else {
		        dispatchKeyEvent((KeyEvent) evt);
		    }
		}
		*/
	}

	/**
	 * Dispatches the specified SWT key event.
	 * @param evt the key event to dispatch
	 */
	protected void dispatchKeyEvent(KeyEvent evt, int type) {
		currentKeyEventTarget = lastHit;
		if (currentKeyEventTarget != null) {
			evt.stateMask = toSVGEvent(evt.stateMask, 0);
			processKeyEvent(
				new GraphicsNodeKeyEvent(
					currentKeyEventTarget,
					type,
					evt.time,
					evt.stateMask,
					evt.keyCode,
					evt.character));
		}
	}

	private int toSVGEvent(int mask, int button) {
		int swt = mask | SWT.MODIFIER_MASK;
		int svg = 0;
		if (swt != 0) {
			// Key modifiers
			// MOD1, MOD2 , MOD3 modifiers not mapped
			if ((swt & SWT.CONTROL) != 0)
				svg |= GraphicsNodeInputEvent.CTRL_MASK;
			if ((swt & SWT.SHIFT) != 0)
				svg |= GraphicsNodeInputEvent.SHIFT_MASK;
			if ((swt & SWT.ALT) != 0)
				svg |= GraphicsNodeInputEvent.ALT_MASK;
			// Mouse button conversion
			switch (button) {
				case 0 :
					break;
				case 1 :
					svg |= GraphicsNodeInputEvent.BUTTON1_MASK;
					break;
				case 2 :
					svg |= GraphicsNodeInputEvent.BUTTON2_MASK;
					break;
				case 3 :
					svg |= GraphicsNodeInputEvent.BUTTON3_MASK;
					break;
				default :
					// Does anybody on Earth have more than 3 regular buttons ?
					svg |= GraphicsNodeInputEvent.BUTTON1_MASK;
					break;
			}
		}
		return svg;
	}

	/**
	 * Dispatches the specified SWT mouse event.
	 * 
	 * @param evt the mouse event to dispatch
	 * @param type the SVG event type to dispatch
	 */
	protected void dispatchMouseEvent(MouseEvent evt, int type) {
		GraphicsNode root = getRootNode();
		if (root == null)
			return;

		GraphicsNodeMouseEvent gvtevt;
		Point2D p = new Point2D.Float(evt.x, evt.y);
		Point2D gnp = p;
		AffineTransform baseTransform = getBaseTransform();
		if ((baseTransform != null) && !baseTransform.isIdentity()) {
			gnp = baseTransform.transform(p, null);
		}

		GraphicsNode node = root.nodeHitAt(gnp);

		// If the receiving node has changed, send a notification
		// check if we enter a new node
		Point screenPos = ((Control) evt.widget).toDisplay(evt.x, evt.y);
		screenPos.x += evt.x;
		screenPos.y += evt.y;

		int clickCount = 1;
		// Click count is taken from evt.data if necessary
		if (evt.data != null) {
			clickCount = ((Integer) evt.data).intValue();
		}

		evt.stateMask = toSVGEvent(evt.stateMask, evt.button);

		if (lastHit != node) {
			// post an MOUSE_EXITED
			if (lastHit != null) {
				gvtevt =
					new GraphicsNodeMouseEvent(
						lastHit,
						GraphicsNodeMouseEvent.MOUSE_EXITED,
						evt.time,
						evt.stateMask,
						(float) gnp.getX(),
						(float) gnp.getY(),
						(int) Math.floor(p.getX()),
						(int) Math.floor(p.getY()),
						screenPos.x,
						screenPos.y,
						clickCount,
						node);
				processMouseEvent(gvtevt);
				// lastHit.processMouseEvent(gvtevt);
			}
			// post an MOUSE_ENTERED
			if (node != null) {
				gvtevt =
					new GraphicsNodeMouseEvent(
						node,
						GraphicsNodeMouseEvent.MOUSE_ENTERED,
						evt.time,
						evt.stateMask,
						(float) gnp.getX(),
						(float) gnp.getY(),
						(int) Math.floor(p.getX()),
						(int) Math.floor(p.getY()),
						screenPos.x,
						screenPos.y,
						clickCount,
						lastHit);
				processMouseEvent(gvtevt);
				// node.processMouseEvent(gvtevt);
			}
		}
		// In all cases, dispatch the original event
		if (node != null) {
			gvtevt =
				new GraphicsNodeMouseEvent(
					node,
					type,
					evt.time,
					evt.stateMask,
					(float) gnp.getX(),
					(float) gnp.getY(),
					(int) Math.floor(p.getX()),
					(int) Math.floor(p.getY()),
					screenPos.x,
					screenPos.y,
					clickCount,
					null);

			// node.processMouseEvent(gvtevt);
			processMouseEvent(gvtevt);

		} else if (
			node == null
				&& type == GraphicsNodeMouseEvent.MOUSE_RELEASED
				&& clickCount == 1) {
			// this is a deselect event, dispatch it to dummy node
			gvtevt =
				new GraphicsNodeMouseEvent(
					dummyNode,
					type,
					evt.time,
					evt.stateMask,
					(float) gnp.getX(),
					(float) gnp.getY(),
					(int) Math.floor(p.getX()),
					(int) Math.floor(p.getY()),
					screenPos.x,
					screenPos.y,
					clickCount,
					null);

			processMouseEvent(gvtevt);
		}
		lastHit = node;
	}

	/**
	 * Processes the specified event by firing the 'global' listeners
	 * attached to this event dispatcher.
	 * @param evt the event to process
	 */
	protected void processMouseEvent(GraphicsNodeMouseEvent evt) {
		if (glisteners != null) {
			GraphicsNodeMouseListener[] listeners =
				(GraphicsNodeMouseListener[]) getListeners(GraphicsNodeMouseListener
					.class);
			switch (evt.getID()) {
				case GraphicsNodeMouseEvent.MOUSE_MOVED :
					for (int i = 0; i < listeners.length; i++) {
						listeners[i].mouseMoved(evt);
					}
					break;
				case GraphicsNodeMouseEvent.MOUSE_DRAGGED :
					for (int i = 0; i < listeners.length; i++) {
						listeners[i].mouseDragged(evt);
					}
					break;
				case GraphicsNodeMouseEvent.MOUSE_ENTERED :
					for (int i = 0; i < listeners.length; i++) {
						listeners[i].mouseEntered(evt);
					}
					break;
				case GraphicsNodeMouseEvent.MOUSE_EXITED :
					for (int i = 0; i < listeners.length; i++) {
						listeners[i].mouseExited(evt);
					}
					break;
				case GraphicsNodeMouseEvent.MOUSE_CLICKED :
					for (int i = 0; i < listeners.length; i++) {
						listeners[i].mouseClicked(evt);
					}
					break;
				case GraphicsNodeMouseEvent.MOUSE_PRESSED :
					for (int i = 0; i < listeners.length; i++) {
						listeners[i].mousePressed(evt);
					}
					break;
				case GraphicsNodeMouseEvent.MOUSE_RELEASED :
					for (int i = 0; i < listeners.length; i++) {
						listeners[i].mouseReleased(evt);
					}
					break;
				default :
					throw new Error("Unknown Mouse Event type: " + evt.getID());
			}
		}
	}

	/**
	 * Dispatches a graphics node key event to by firing the 'global'
	 * listeners attached to this event dispatcher.
	 *
	 * @param evt the evt to dispatch
	 */
	public void processKeyEvent(GraphicsNodeKeyEvent evt) {
		if ((glisteners != null)) {
			GraphicsNodeKeyListener[] listeners =
				(GraphicsNodeKeyListener[]) getListeners(GraphicsNodeKeyListener
					.class);

			switch (evt.getID()) {
				case GraphicsNodeKeyEvent.KEY_PRESSED :
					for (int i = 0; i < listeners.length; ++i) {
						listeners[i].keyPressed(evt);
					}
					break;
				case GraphicsNodeKeyEvent.KEY_RELEASED :
					for (int i = 0; i < listeners.length; ++i) {
						listeners[i].keyReleased(evt);
					}
					break;
				case GraphicsNodeKeyEvent.KEY_TYPED :
					for (int i = 0; i < listeners.length; ++i) {
						listeners[i].keyTyped(evt);
					}
					break;
				default :
					throw new Error("Unknown Key Event type: " + evt.getID());
			}
		}
		evt.consume();
	}

	private void incrementKeyTarget() {
		// <!> FIXME TODO: Not implemented.
		throw new Error("Increment not implemented.");
	}

	private void decrementKeyTarget() {
		// <!> FIXME TODO: Not implemented.
		throw new Error("Decrement not implemented.");
	}

	/**
	 * Associates all InputEvents of type <tt>e.getID()</tt>
	 * with "incrementing" of the currently selected GraphicsNode.
	 */
	public void setNodeIncrementEvent(InputEvent e) {
		/*
		nodeIncrementEventID = e.getID();
		if (e instanceof KeyEvent) {
		    nodeIncrementEventCode = ((KeyEvent) e).keyCode;
			nodeIncrementEventModifiers = ((KeyEvent) e).stateMask;
		}
		*/
	}

	/**
	 * Associates all InputEvents of type <tt>e.getID()</tt>
	 * with "decrementing" of the currently selected GraphicsNode.
	 * The notion of "currently selected" GraphicsNode is used
	 * for dispatching KeyEvents.
	 */
	public void setNodeDecrementEvent(InputEvent e) {
		/*
		nodeDecrementEventID = e.getID();
		if (e instanceof KeyEvent) {
		    nodeDecrementEventCode = ((KeyEvent) e).keyCode;
			nodeDecrementEventModifiers = ((KeyEvent) e).stateMask;
		}
		*/
	}

	/**
	 * Returns true if the input event e is a node increment event,
	 * false otherwise.
	 * @param e the input event
	 */
	/*
	protected boolean isNodeIncrementEvent(InputEvent e) {
	    // TODO: Improve code readability!
	    return ((e.getID() == nodeIncrementEventID) &&
	            ((e instanceof KeyEvent) ?
	                 (((KeyEvent) e).getKeyCode() == nodeIncrementEventCode) : true) &&
	            ((e.getModifiers() & nodeIncrementEventModifiers) != 0));
	}
	*/

	/**
	 * Returns true if the input event e is a node decrement event,
	 * false otherwise.
	 */
	/*
	protected boolean isNodeDecrementEvent(InputEvent e) {
	    // TODO: Improve code readability!
	    return ((e.getID() == nodeDecrementEventID) &&
	            ((e instanceof KeyEvent) ?
	                 ( ((KeyEvent) e).getKeyCode() == nodeDecrementEventCode) : true) &&
	            ((e.getModifiers() & nodeDecrementEventModifiers) != 0  ));
	
	}
	*/
}
