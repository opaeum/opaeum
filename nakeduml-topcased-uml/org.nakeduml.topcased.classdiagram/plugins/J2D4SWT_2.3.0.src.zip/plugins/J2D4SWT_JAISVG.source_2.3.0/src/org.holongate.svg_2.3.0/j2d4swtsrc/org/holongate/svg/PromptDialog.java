/*****************************************************************************
 * Copyright (c) 2002-2004, Holongate.org.                                   *
 *                                                                           *
 * All rights reserved. This program and the accompanying materials are made *
 * available under the terms of the Common Public License v1.0 which         *
 * accompanies this distribution, and is available at                        *
 * http://www.eclipse.org/legal/cpl-v10.html                                 *
 *                                                                           *
 * Contributors:                                                             *
 *               Christophe Avare - initial API and implementation           *
 *****************************************************************************/
package org.holongate.svg;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

/**
 * A simple SWT dialog with an input field.
 * 
 * @author Christophe Avare
 * @version $Revision: 1.1.4.1 $
 */
public class PromptDialog extends Dialog {
	private String value;
	private String message;
	/**
	 * @param parent
	 */
	public PromptDialog(Shell parent) {
		super(parent, SWT.DEFAULT);
	}

	/**
	 * @param parent
	 * @param style
	 */
	public PromptDialog(Shell parent, int style) {
		super(parent, style);
	}

	public String getValue() {
		return value;
	}

	public void open() {
		Shell parent = getParent();
		Shell shell =
			new Shell(parent, SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
		shell.setText(getText());
		shell.setLayout(new GridLayout(1, true));
		if (message != null) {
			Label msg = new Label(shell, SWT.NONE);
			msg.setText(message);
		}
		final Text input = new Text(shell, SWT.SINGLE);
		input.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				setValue(input.getText());
			}
		});
		if (value != null) {
			input.setText(value);
		}
		Display display = parent.getDisplay();
		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String string) {
		message = string;
	}

	public void setValue(String string) {
		value = string;
	}

}
