/**
 * The package contains several spinners for JIDE Common Layer.
 */
package com.jidesoft.spinner;