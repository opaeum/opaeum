/**
 * The package contains all kinds of object groupers for JIDE Common Layer.
 */
package com.jidesoft.grouper;